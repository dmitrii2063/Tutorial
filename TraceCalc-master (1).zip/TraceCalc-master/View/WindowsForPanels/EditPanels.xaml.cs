﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;
using TraceCalc.View.WindowsForEnvironment;

namespace TraceCalc.View.WindowsForPnales
{
    /// <summary>
    /// Логика взаимодействия для EditPanels.xaml
    /// </summary>
    public partial class EditPanels : Window
    {
        public Action PanelsChanged;
        public EditPanels()
        {
            InitializeComponent();
            LoadPanels();
        }
        private void LoadPanels()
        {
            PanelsDataGrid.ItemsSource = Config.Config.Instance.Panels;
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            AddOrEditPanels addOrEditPanels = new AddOrEditPanels();
            if(addOrEditPanels.ShowDialog() == true)
            {
                var newPanel = addOrEditPanels.NewPanel;
                if (newPanel != null)
                {
                    Config.Config.Instance.Panels.Add(newPanel);
                    PanelsDataGrid.ItemsSource = null;
                    PanelsDataGrid.ItemsSource = Config.Config.Instance.Panels;
                    PanelsChanged?.Invoke();
                }
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = PanelsDataGrid.SelectedItem;

            if (selectedItem != null)
            {
                var panelItem = selectedItem as Panels;

                var editWindow = new AddOrEditPanels(panelItem);
                if (editWindow.ShowDialog() == true)
                {
                    var editedPanel = editWindow.NewPanel;

                    if (editedPanel != null)
                    {
                        int index = Config.Config.Instance.Panels.IndexOf(panelItem);
                        if (index >= 0)
                        {
                            Config.Config.Instance.Panels[index] = editedPanel;
                        }

                        PanelsDataGrid.ItemsSource = null;
                        PanelsDataGrid.ItemsSource = Config.Config.Instance.Panels;
                        PanelsChanged?.Invoke();
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedPanel = PanelsDataGrid.SelectedItem as Panels;

            if (selectedPanel == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
                return;
            }

            MessageBoxResult answer = MessageBox.Show(@"Вы точно хотите удалить эту запись?",
                                                        "Подтверждение удаления",
                                                        MessageBoxButton.YesNo,
                                                        MessageBoxImage.Warning);

            if (answer == MessageBoxResult.Yes)
            {
                DeleteSelectedRow(selectedPanel);
                Config.Config.Instance.Panels.Remove(selectedPanel);
                PanelsDataGrid.ItemsSource = null;
                PanelsDataGrid.ItemsSource = Config.Config.Instance.Areas;
                PanelsChanged?.Invoke();
                PanelsDataGrid.Items.Refresh();
            }
            else
            {
                return;
            }
        }
        private void DeleteSelectedRow(Panels panel)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    Panels = new List<Panels>()
                };
            }

            var panelToDelete = pipesCollection.Panels.FirstOrDefault(x => x.NameOfPanel == panel.NameOfPanel);
            if (panelToDelete == null)
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }
            pipesCollection.Panels.Remove(panelToDelete);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);

        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
