﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;

namespace TraceCalc.View.WindowsForPnales
{
    /// <summary>
    /// Логика взаимодействия для AddOrEditPanels.xaml
    /// </summary>
    public partial class AddOrEditPanels : Window
    {
        private Panels _panel;
        public Panels NewPanel { get; private set; }
        public AddOrEditPanels()
        {
            InitializeComponent();
            LoadParam(null);
        }
        public AddOrEditPanels(Panels panel)
        {
            _panel = panel;
            InitializeComponent();
            LoadParam(_panel);
        }
        private void LoadParam(Panels panel)
        {
            NameOfPanel.Text = panel?.NameOfPanel ?? "";
            RegMethod.Text = panel?.RegMethod ?? "";
            Product.Text = panel?.Product ?? "";
        }
        private void Ok_Button_Click(object sender, RoutedEventArgs e)
        {
            var panelName = NameOfPanel.Text.Trim();

            if (string.IsNullOrEmpty(panelName))
            {
                MessageBox.Show("Имя области не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            NewPanel = new Panels()
            {
                NameOfPanel = panelName,
                RegMethod = RegMethod.Text,
                Product = Product.Text,
            };


            if (_panel == null)
            {
                Save(NewPanel);
            }
            else
            {
                Update(_panel, NewPanel);
            }

            DialogResult = true;
            Close();
        }

        private void Save(Panels panel)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure generalCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                generalCollection = new GeneralStructure
                {
                    Panels = new List<Panels>()
                };
            }

            generalCollection.Panels.Add(panel);
            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

        private void Update(Panels existingPanel, Panels newPanel)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            var generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(File.ReadAllText(filePath));

            var panelToUpdate = generalCollection.Panels.FirstOrDefault(a => a.NameOfPanel == existingPanel.NameOfPanel);
            if (panelToUpdate != null)
            {
                panelToUpdate.NameOfPanel = newPanel.NameOfPanel;
            }

            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
