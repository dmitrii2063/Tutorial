﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TraceCalc.View.WindowsForProject
{
    /// <summary>
    /// Логика взаимодействия для ProjSettings.xaml
    /// </summary>
    public partial class ProjSettings : Window
    {
        private List<string> selectedPipes = new List<string>();
        public ProjSettings()
        {
            InitializeComponent();
            Load();
        }
        private void Load()
        {
            var heatGroupCables = Config.Config.Instance.HeatCables;
            var sensors = Config.Config.Instance.Sensors;
            var controls = Config.Config.Instance.LocalControls;
            var pipeTypes = Config.Config.Instance.Pipes;

            foreach (var group in heatGroupCables)
            {
                var groupItem = new StackPanel { Orientation = Orientation.Horizontal };
                var checkBoxForGroup = new CheckBox { Content = group.HeatCablesGroupName };

                groupItem.Children.Add(checkBoxForGroup);

                var treeViewItem = new TreeViewItem();
                treeViewItem.Header = groupItem;

                foreach (var cable in group.HeatCablesName)
                {
                    CheckBox checkBoxForItem = new CheckBox { Content = cable.Name };

                    treeViewItem.Items.Add(checkBoxForItem);
                }

                TreeOfType.Items.Add(treeViewItem);
            }

            foreach (var sensor in sensors)
            {
                var groupItem = new StackPanel { Orientation = Orientation.Horizontal };
                // Разделяем строку на части
                var sensorParts = sensor.SensorName.Split(new[] { " - " }, 2, StringSplitOptions.None);

                // Проверяем, есть ли описание после разделения
                string description = sensorParts.Length > 1 ? sensorParts[1] : sensor.SensorName; // Если нет описания, используем оригинальное имя

                var checkBoxForGroup = new CheckBox { Content = description };

                groupItem.Children.Add(checkBoxForGroup);

                var treeViewItem = new TreeViewItem();
                treeViewItem.Header = groupItem;

                SensorsTree.Items.Add(treeViewItem);
            }
            foreach(var controlItem in controls)
            {
                var groupItem = new StackPanel { Orientation = Orientation.Horizontal };
                var checkBoxForGroup = new CheckBox { Content = controlItem.LocalControlName };

                groupItem.Children.Add(checkBoxForGroup);

                var treeViewItem = new TreeViewItem();
                treeViewItem.Header = groupItem;

                LoLocalControl.Items.Add(treeViewItem);
            }
            foreach (var pipe in pipeTypes.Where(x=>!string.IsNullOrWhiteSpace(x.Name)))
            {
                var groupItem = new StackPanel { Orientation = Orientation.Horizontal };
                var checkBoxForGroup = new CheckBox { Content = pipe.Name };
                checkBoxForGroup.Checked += CheckBoxForGroup_Checked;
                checkBoxForGroup.Unchecked += CheckBoxForGroup_Unchecked;
                groupItem.Children.Add(checkBoxForGroup);

                var treeViewItem = new TreeViewItem();
                treeViewItem.Header = groupItem;

                PipeTypeBox.Items.Add(treeViewItem);
            }
        }
        private void CheckBoxForGroup_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox checkBox)
            {
                selectedPipes.Add(checkBox.Content.ToString()); // Добавляем выбранную трубу
            }
        }

        private void CheckBoxForGroup_Unchecked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox checkBox)
            {
                selectedPipes.Remove(checkBox.Content.ToString()); // Удаляем снятую с выбора трубу
            }
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            this.Tag = selectedPipes;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
    }
}
