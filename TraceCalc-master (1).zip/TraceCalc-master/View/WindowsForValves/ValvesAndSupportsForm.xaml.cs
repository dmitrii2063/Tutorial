﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;

namespace TraceCalc
{
    /// <summary>
    /// Логика взаимодействия для ValvesAndSupports.xaml
    /// </summary>
    public partial class ValvesAndSupports: Window
    {
        public ValvesAndSupports()
        {
            InitializeComponent();
            LoadValvesAndSupports();
        }
        private void LoadValvesAndSupports()
        {
            var config = Config.Config.Instance.ValvesAndSupportsAndFlangs;
            foreach (var valve in config.Valves)
            {
                Valve newValve = new Valve(valve.Type, valve.Description, valve.Mode, valve.ImagePath);
                Type1ComboBox.Items.Add(newValve);
                Type2ComboBox.Items.Add(newValve); 
                Type3ComboBox.Items.Add(newValve);
            }
            foreach (var support in config.Supports)
            {
                Valve newSupport = new Valve(support.Type, support.Description, support.Mode, support.ImagePath);
                Type1_SupComboBox.Items.Add(newSupport);
                Type2_SupComboBox.Items.Add(newSupport);
                Type3_SupComboBox.Items.Add(newSupport);
            }
            foreach (var flang in config.Flangs)
            {
                Valve newFlang = new Valve(flang.Type, flang.Description, flang.Mode, flang.ImagePath);
                Type1_FlComboBox.Items.Add(newFlang);
            }
        }

        #region Элементы на форме

        #region Задвижки
        private void Type1ComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type1ComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type1_SecondComboBox.Items.Clear();
                Type1_SecondComboBox.Items.Add(selectedValve.Mode);
                Type1_SecondComboBox.SelectedItem = selectedValve.Mode;

                Type1_SecondComboBox.IsEnabled = true;
                Type1TextBox.IsEnabled = true;
                Type1TextBox.Text = "1";
                Type1CheckBox.IsEnabled = true;
                Type1ComboBox.Height = 25;
                Type1ComboBox.Text = selectedValve.Type;
            }
            else
            {
                Type1_SecondComboBox.IsEnabled = false;
                Type1_SecondComboBox.SelectedItem = null;
                Type1TextBox.IsEnabled = false;
                Type1CheckBox.IsEnabled = false;
                Type1CheckBox.IsChecked = false;
                Type1TextBox.Clear();
                Type1ComboBox.Text = "";
            }
        }
        private void Type2ComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type2ComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type2_SecondComboBox.Items.Clear();
                Type2_SecondComboBox.Items.Add(selectedValve.Mode);
                Type2_SecondComboBox.SelectedItem = selectedValve.Mode;

                Type2_SecondComboBox.IsEnabled = true;
                Type2TextBox.IsEnabled = true;
                Type2TextBox.Text = "1";
                Type2CheckBox.IsEnabled = true;
                Type2ComboBox.Height = 25;
                Type2ComboBox.Text = selectedValve.Type;
            }
            else
            {
                Type2_SecondComboBox.IsEnabled = false;
                Type2_SecondComboBox.SelectedItem = null;
                Type2TextBox.IsEnabled = false;
                Type2CheckBox.IsEnabled = false;
                Type2CheckBox.IsChecked = false;
                Type2TextBox.Clear();
                Type2ComboBox.Text = "";
            }
        }
        private void Type3ComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type3ComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type3_SecondComboBox.Items.Clear();
                Type3_SecondComboBox.Items.Add(selectedValve.Mode);
                Type3_SecondComboBox.SelectedItem = selectedValve.Mode;

                Type3_SecondComboBox.IsEnabled = true;
                Type3TextBox.IsEnabled = true;
                Type3TextBox.Text = "1";
                Type3CheckBox.IsEnabled = true;
                Type3ComboBox.Height = 25;
                Type3ComboBox.Text = selectedValve.Type;
            }
            else
            {
                Type3_SecondComboBox.IsEnabled = false;
                Type3_SecondComboBox.SelectedItem = null;
                Type3TextBox.IsEnabled = false;
                Type3CheckBox.IsEnabled = false;
                Type3CheckBox.IsChecked = false;
                Type3TextBox.Clear();
                Type3ComboBox.Text = "";
            }
        }


        private void Type1CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type1_SecondTextBox.Text = "6.10";
        }
        private void Type1CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type1_SecondTextBox.Clear();
        }

        private void Type2CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type2_SecondTextBox.Text = "6.10";
        }
        private void Type2CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type2_SecondTextBox.Clear();
        }

        private void Type3CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type3_SecondTextBox.Text = "6.10";
        }
        private void Type3CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type3_SecondTextBox.Clear();
        }
        #endregion

        #region Опоры
        private void Type1_SupComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type1_SupComboBox.SelectedItem as Valve;

            if (selectedValve != null )
            {
                Type1_SupSecondComboBox.Items.Clear();
                Type1_SupSecondComboBox.Items.Add(selectedValve.Mode);
                Type1_SupSecondComboBox.SelectedItem = selectedValve.Mode;

                Type1_SupSecondComboBox.IsEnabled = true;
                Type1_SupCheckBox.IsEnabled = true;
                Type1_SupSecondTextBox.IsEnabled = true;
                Type1_SupSecondCheckBox.IsEnabled = true;
                Type1_SupTextBox.Text = "7,0";
                Type1_SupSecondTextBox.Text = "8";
                Type1_SupComboBox.Height = 25;
                Type1_SupComboBox.Text = selectedValve.Type;

            }
            else
            {
                Type1_SupSecondComboBox.SelectedItem = null;
                Type1_SupSecondComboBox.IsEnabled = false;
                Type1_SupCheckBox.IsEnabled = false;
                Type1_SupTextBox.IsEnabled = false;
                Type1_SupSecondTextBox.IsEnabled = false;
                Type1_SupSecondCheckBox.IsEnabled = false;
                Type1_SupThirdTextBox.IsEnabled = false;
                Type1_SupTextBox.Clear();
                Type1_SupSecondTextBox.Clear();
                Type1_SupCheckBox.IsChecked = false;
                Type1_SupSecondCheckBox.IsChecked = false;
                Type1_SupComboBox.Text = "";
            }
        }
        private void Type1_SupCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type1_SupSecondTextBox.IsEnabled = false;
            Type1_SupTextBox.IsEnabled = true;
        }
        private void Type1_SupCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type1_SupSecondTextBox.IsEnabled = true;
            Type1_SupTextBox.IsEnabled = false;
        }

        private void Type1_SupSecondCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type1_SupThirdTextBox.IsEnabled = true;
            Type1_SupThirdTextBox.Text = "6,10";
        }
        private void Type1_SupSecondCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type1_SupThirdTextBox.IsEnabled = false;
            Type1_SupThirdTextBox.Clear();
        }



        private void Type2_SupComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type2_SupComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type2_SupSecondComboBox.Items.Clear();
                Type2_SupSecondComboBox.Items.Add(selectedValve.Mode);
                Type2_SupSecondComboBox.SelectedItem = selectedValve.Mode;

                Type2_SupSecondComboBox.IsEnabled = true;
                Type2_SupCheckBox.IsEnabled = true;
                Type2_SupSecondTextBox.IsEnabled = true;
                Type2_SupSecondCheckBox.IsEnabled = true;
                Type2_SupTextBox.Text = "7,0";
                Type2_SupSecondTextBox.Text = "8";
                Type2_SupComboBox.Height = 25;
                Type2_SupComboBox.Text = selectedValve.Type;

            }
            else
            {
                Type2_SupSecondComboBox.SelectedItem = null;
                Type2_SupSecondComboBox.IsEnabled = false;
                Type2_SupCheckBox.IsEnabled = false;
                Type2_SupTextBox.IsEnabled = false;
                Type2_SupSecondTextBox.IsEnabled = false;
                Type2_SupSecondCheckBox.IsEnabled = false;
                Type2_SupThirdTextBox.IsEnabled = false;
                Type2_SupTextBox.Clear();
                Type2_SupSecondTextBox.Clear();
                Type2_SupCheckBox.IsChecked = false;
                Type2_SupSecondCheckBox.IsChecked = false;
                Type2_SupComboBox.Text = "";
            }
        }
        private void Type2_SupCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type2_SupSecondTextBox.IsEnabled = false;
            Type2_SupTextBox.IsEnabled = true;
        }
        private void Type2_SupCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type2_SupSecondTextBox.IsEnabled = true;
            Type2_SupTextBox.IsEnabled = false;
        }

        private void Type2_SupSecondCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type2_SupThirdTextBox.IsEnabled = true;
            Type2_SupThirdTextBox.Text = "6,10"; // Установить текст по умолчанию
        }
        private void Type2_SupSecondCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type2_SupThirdTextBox.IsEnabled = false;
            Type2_SupThirdTextBox.Clear();
        }

        private void Type3_SupComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type3_SupComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type3_SupSecondComboBox.Items.Clear();
                Type3_SupSecondComboBox.Items.Add(selectedValve.Mode);
                Type3_SupSecondComboBox.SelectedItem = selectedValve.Mode;

                Type3_SupSecondComboBox.IsEnabled = true;
                Type3_SupCheckBox.IsEnabled = true;
                Type3_SupSecondTextBox.IsEnabled = true;
                Type3_SupSecondCheckBox.IsEnabled = true;
                Type3_SupTextBox.Text = "7,0";
                Type3_SupSecondTextBox.Text = "8";
                Type3_SupComboBox.Height = 25;
                Type3_SupComboBox.Text = selectedValve.Type;
            }
            else
            {
                Type3_SupSecondComboBox.SelectedItem = null;
                Type3_SupSecondComboBox.IsEnabled = false;
                Type3_SupCheckBox.IsEnabled = false;
                Type3_SupTextBox.IsEnabled = false;
                Type3_SupSecondTextBox.IsEnabled = false;
                Type3_SupSecondCheckBox.IsEnabled = false;
                Type3_SupThirdTextBox.IsEnabled = false;
                Type3_SupTextBox.Clear();
                Type3_SupSecondTextBox.Clear();
                Type3_SupCheckBox.IsChecked = false;
                Type3_SupSecondCheckBox.IsChecked = false;
                Type3_SupComboBox.Text = "";
            }
        }
        private void Type3_SupCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type3_SupSecondTextBox.IsEnabled = false;
            Type3_SupTextBox.IsEnabled = true;
        }
        private void Type3_SupCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type3_SupSecondTextBox.IsEnabled = true;
            Type3_SupTextBox.IsEnabled = false;
        }

        private void Type3_SupSecondCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type3_SupThirdTextBox.IsEnabled = true;
            Type3_SupThirdTextBox.Text = "6,10"; // Установить текст по умолчанию
        }
        private void Type3_SupSecondCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type3_SupThirdTextBox.IsEnabled = false;
            Type3_SupThirdTextBox.Clear();
        }



        #endregion

        #region Фланцы
        private void Type1_FlComboBox_Changed(object sender, SelectionChangedEventArgs e)
        {
            var selectedValve = Type1_FlComboBox.SelectedItem as Valve;

            if (selectedValve != null)
            {
                Type1_FlSecondComboBox.Items.Clear();
                Type1_FlSecondComboBox.Items.Add(selectedValve.Mode);
                Type1_FlSecondComboBox.SelectedItem = selectedValve.Mode;

                Type1_FlSecondComboBox.IsEnabled = true;
                Type1_FlCheckBox.IsEnabled = true;
                Type1_FlSecondTextBox.IsEnabled = true;
                Type1_FlSecondCheckBox.IsEnabled = true;
                Type1_FlTextBox.Text = "999,0";
                Type1_FlSecondTextBox.Text = "1";
                Type1_FlComboBox.Height = 25;
                Type1_FlComboBox.Text = selectedValve.Type;
            }
            else
            {
                Type1_FlSecondComboBox.SelectedItem = null;
                Type1_FlSecondComboBox.IsEnabled = false;
                Type1_FlCheckBox.IsEnabled = false;
                Type1_FlTextBox.IsEnabled = false;
                Type1_FlSecondTextBox.IsEnabled = false;
                Type1_FlSecondCheckBox.IsEnabled = false;
                Type1_FlThirdTextBox.IsEnabled = false;
                Type1_FlTextBox.Clear();
                Type1_FlSecondTextBox.Clear();
                Type1_FlCheckBox.IsChecked = false;
                Type1_FlSecondCheckBox.IsChecked = false;
                Type1_FlComboBox.Text = "";
            }
        }
        private void Type1_FlCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type1_FlSecondTextBox.IsEnabled = false;
            Type1_FlTextBox.IsEnabled = true;
        }
        private void Type1_FlCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type1_FlSecondTextBox.IsEnabled = true;
            Type1_FlTextBox.IsEnabled = false;
        }
        private void Type1_FlSecondCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Устанавливаем текст в TextBox, когда чекбокс активируется
            Type1_FlThirdTextBox.IsEnabled = true;
            Type1_FlThirdTextBox.Text = "2,44";
        }
        private void Type1_FlSecondCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Очищаем текст в TextBox, когда чекбокс деактивируется
            Type1_FlThirdTextBox.IsEnabled = false;
            Type1_FlThirdTextBox.Clear();
        }
        #endregion

        private void UseIntervalsChecked(object sender, RoutedEventArgs e)
        {
            if(Type1_SupComboBox.SelectedItem != null)
            {
                Type1_SupCheckBox.IsEnabled = false;
                Type1_SupCheckBox.IsChecked = true;
                Type1_SupTextBox.IsEnabled = false;
            }

            if (Type2_SupComboBox.SelectedItem != null)
            {
                Type2_SupCheckBox.IsEnabled = false;
                Type2_SupCheckBox.IsChecked = true;
                Type2_SupTextBox.IsEnabled = false;
            }

            if (Type3_SupComboBox.SelectedItem != null)
            {
                Type3_SupCheckBox.IsEnabled = false;
                Type3_SupCheckBox.IsChecked = true;
                Type3_SupTextBox.IsEnabled = false;
            }
            
            if(Type1_FlComboBox.SelectedItem != null)
            {
                Type1_FlCheckBox.IsEnabled = false;
                Type1_FlCheckBox.IsChecked = true;
                Type1_FlTextBox.IsEnabled = false;
            }

        }
        private void UseIntervalsUncheked(object sender, RoutedEventArgs e)
        {
            Type1_SupCheckBox.IsEnabled = true;
            Type1_SupTextBox.IsEnabled = true;

            Type2_SupCheckBox.IsEnabled = true;
            Type2_SupTextBox.IsEnabled = true;

            Type3_SupCheckBox.IsEnabled = true;
            Type3_SupTextBox.IsEnabled = true;

            Type1_FlCheckBox.IsEnabled = true;
            Type1_FlTextBox.IsEnabled = true;
        }
        private void RadioButton_No_Checked(object sender, RoutedEventArgs e)
        {
            TextBox_ForRadioButton.IsEnabled = false;
            Label_ForRadioButton.Content = "";
        }
        private void RadioButton_Percent_Checked(object sender, RoutedEventArgs e)
        {
            TextBox_ForRadioButton.IsEnabled = false;
            Label_ForRadioButton.Content = "%";
        }
        private void RadioButton_Temp_Checked(object sender, RoutedEventArgs e)
        {
            TextBox_ForRadioButton.IsEnabled = false;
            Label_ForRadioButton.Content = "W";
        }
        private void RadioButton_Lenght_Checked(object sender, RoutedEventArgs e)
        {
            TextBox_ForRadioButton.IsEnabled = false;
            Label_ForRadioButton.Content = "m";
        }

        #endregion

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class Valve
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public string Mode { get; set; }
        public string ImagePath { get; set; }

        public Valve(string type, string description, string mode, string imagePath)
        {
            Type = type;
            Description = description;
            Mode = mode;
            ImagePath = imagePath;
        }

        public override string ToString()
        {
            return Type;
        }
    }
}
