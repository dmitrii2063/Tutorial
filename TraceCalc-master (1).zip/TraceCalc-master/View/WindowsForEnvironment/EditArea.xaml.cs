﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model.ListsModels;
using TraceCalc.Model;
using System.IO;

namespace TraceCalc.View.WindowsForEnvironment
{
    /// <summary>
    /// Логика взаимодействия для Edit_Environment.xaml
    /// </summary>
    public partial class EditArea : Window
    {
        public Action AreaChanged;
        public EditArea()
        {
            InitializeComponent();
            LoadAreas();
        }

        private void LoadAreas()
        {
            AreasDataGrid.ItemsSource = Config.Config.Instance.Areas;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var areaPropertiesWindow = new AddAndEdit_Environment();
            if (areaPropertiesWindow.ShowDialog() == true)
            {
                var newArea = areaPropertiesWindow.NewArea;
                if (newArea != null)
                {
                    Config.Config.Instance.Areas.Add(newArea);
                    AreasDataGrid.ItemsSource = null;
                    AreasDataGrid.ItemsSource = Config.Config.Instance.Areas;
                    AreaChanged?.Invoke();
                }
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = AreasDataGrid.SelectedItem;

            if (selectedItem != null)
            {
                var areaItem = selectedItem as Areas;

                var editWindow = new AddAndEdit_Environment(areaItem);
                if (editWindow.ShowDialog() == true)
                {
                    var editedArea = editWindow.NewArea;

                    if (editedArea != null)
                    {
                        int index = Config.Config.Instance.Areas.IndexOf(areaItem);
                        if (index >= 0)
                        {
                            Config.Config.Instance.Areas[index] = editedArea;
                        }

                        AreasDataGrid.ItemsSource = null;
                        AreasDataGrid.ItemsSource = Config.Config.Instance.Areas;
                        AreaChanged?.Invoke();
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedArea = AreasDataGrid.SelectedItem as Areas;

            if (selectedArea == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
                return;
            }

            MessageBoxResult answer = MessageBox.Show(@"Вы точно хотите удалить эту запись?",
                                                        "Подтверждение удаления",
                                                        MessageBoxButton.YesNo,
                                                        MessageBoxImage.Warning);

            if (answer == MessageBoxResult.Yes)
            {
                DeleteSelectedRow(selectedArea);
                Config.Config.Instance.Areas.Remove(selectedArea);
                AreasDataGrid.ItemsSource = null;
                AreasDataGrid.ItemsSource = Config.Config.Instance.Areas;
                AreaChanged?.Invoke();
                AreasDataGrid.Items.Refresh();
            }
            else
            {
                return;
            }

        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void DeleteSelectedRow(Areas area)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    Areas = new List<Areas>()
                };
            }

            var areaToDelete = pipesCollection.Areas.FirstOrDefault(x => x.AreaName == area.AreaName);
            if (areaToDelete == null)
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }
            pipesCollection.Areas.Remove(areaToDelete);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);

        }
    }
}


