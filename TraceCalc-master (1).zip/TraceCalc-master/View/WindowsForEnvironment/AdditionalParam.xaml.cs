﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;

namespace TraceCalc.View.WindowsForEnvironment
{
    /// <summary>
    /// Логика взаимодействия для AdditionalParam.xaml
    /// </summary>
    public partial class AdditionalParam : Window
    {
        public Action ParamChanged;
        private string paramForLiquid;
        private Liquids _liquid;
        public AdditionalParam(string check, Liquids liquid)
        {
            _liquid = liquid;
            paramForLiquid = check;
            InitializeComponent();
            LoadParamForEditWindow(paramForLiquid, _liquid);
        }

        private void LoadParamForEditWindow(string param, Liquids liquid)
        {
            if (param.Contains("Density"))
            {
                ParamBox.Text = liquid.Density;
            }
            if (param.Contains("ThermalConductivity"))
            {
                ParamBox.Text = liquid.ThermalConductivity;

            }
            if (param.Contains("HeatCapacity"))
            {
                ParamBox.Text = liquid.HeatCapacity;

            }
        }
        private void Ok_Button_Click(object sender, RoutedEventArgs e)
        {
            var param = ParamBox.Text;

            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            var generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(File.ReadAllText(filePath));
            var updateLiquid = generalCollection.Liquids.FirstOrDefault(a => a.NameOfLiquid == _liquid.NameOfLiquid);
            if (updateLiquid != null)
            {
                if (paramForLiquid.Contains("Density"))
                {
                    updateLiquid.Density = param;
                }
                if (paramForLiquid.Contains("HeatCapacity"))
                {
                    updateLiquid.HeatCapacity = param;
                }
                if (paramForLiquid.Contains("ThermalConductivity"))
                {
                    updateLiquid.ThermalConductivity = param;
                }
            }

            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
            ParamChanged?.Invoke();
            DialogResult = true;
            Close();
        }

        private void Cancel_Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
