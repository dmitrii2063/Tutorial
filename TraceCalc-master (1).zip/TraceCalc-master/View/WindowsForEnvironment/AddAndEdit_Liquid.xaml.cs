﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model.ListsModels;
using TraceCalc.Model;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.IO;

namespace TraceCalc.View.WindowsForEnvironment
{
    /// <summary>
    /// Логика взаимодействия для Add_Liquid.xaml
    /// </summary>
    public partial class AddAndEdit_Liquid : Window
    {
        private Liquids _liquid;
        public Liquids NewLiquid { get; private set; }

        public AddAndEdit_Liquid()
        {
            InitializeComponent();
            LoadParamForEditWindow(null);
        }
        public AddAndEdit_Liquid(Liquids liquid)
        {
            _liquid = liquid;
            InitializeComponent();
            LoadParamForEditWindow(_liquid);
        }
        private void LoadParamForEditWindow(Liquids liquid)
        {
            IdTextBox.Text = liquid?.NameOfLiquid ?? "";
            DescriptionTextBox.Text = liquid?.Description ?? "";
            LatentHeatOfFusion.Text = liquid?.LatentHeatOfFusion ?? "";
            LatentHeatOfFusionIsFound.Text = liquid?.LatentHeatOfFusionIsFound ?? "";
            LatentHeatOfVaporization.Text = liquid?.LatentHeatOfVaporization ?? "";
            LatentHeatOfVaporizationIsFound.Text = liquid?.LatentHeatOfVaporizationIsFound ?? "";
            CanFreeze.IsChecked = liquid?.CanFreeze ?? true;
            CanBoil.IsChecked = liquid?.CanBoil ?? true;
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            var nameOfLiquid = IdTextBox.Text;

            if (string.IsNullOrEmpty(nameOfLiquid))
            {
                MessageBox.Show("Имя не может быть пустым!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NewLiquid = new Liquids()
            {
                NameOfLiquid = IdTextBox.Text,
                Description = DescriptionTextBox.Text,
                LatentHeatOfFusion = LatentHeatOfFusion.Text,
                LatentHeatOfFusionIsFound = LatentHeatOfFusionIsFound.Text,
                LatentHeatOfVaporization = LatentHeatOfVaporization.Text,
                LatentHeatOfVaporizationIsFound = LatentHeatOfVaporizationIsFound.Text,
                CanBoil = CanBoil.IsChecked,
                CanFreeze = CanFreeze.IsChecked,
            };


            if (_liquid == null)
            {
                Save(NewLiquid);
            }
            else
            {
                Update(_liquid, NewLiquid);
            }

            DialogResult = true;
            Close();
        }

        private void Save(Liquids NewLiquid)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Liquids = new List<Liquids>()
                };
            }

            pipesCollection.Liquids.Add(NewLiquid);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

        private void Update(Liquids existingLiquid, Liquids newLiquid)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            var generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(File.ReadAllText(filePath));

            var liquidToUpdate = generalCollection.Liquids.FirstOrDefault(a => a.NameOfLiquid == existingLiquid.NameOfLiquid);
            if (liquidToUpdate != null)
            {
                liquidToUpdate.Description = newLiquid.Description;
                liquidToUpdate.LatentHeatOfFusion = newLiquid.LatentHeatOfFusion;
                liquidToUpdate.LatentHeatOfFusionIsFound = newLiquid.LatentHeatOfFusionIsFound;
                liquidToUpdate.LatentHeatOfVaporization = newLiquid.LatentHeatOfVaporization;
                liquidToUpdate.LatentHeatOfVaporizationIsFound = newLiquid.LatentHeatOfVaporizationIsFound;
                liquidToUpdate.CanBoil = newLiquid.CanBoil;
                liquidToUpdate.CanFreeze = newLiquid.CanFreeze;
            }
            else
            {
                MessageBox.Show("Такого элемента нет");
                return;
            }
            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void DensityButton_Click(object sender, RoutedEventArgs e)
        {
            var check = "Density";
            var param = new AdditionalParam(check, _liquid);
            if(param.ShowDialog() == true)
            {
                _liquid.Density = param.ParamBox.Text;
            }
        }

        private void ThermalConductivity_Click(object sender, RoutedEventArgs e)
        {
            var check = "ThermalConductivity";
            var param = new AdditionalParam(check, _liquid);
            param.ParamChanged += () =>
            {
                _liquid.ThermalConductivity = param.ParamBox.Text;
            };
            if (param.ShowDialog() == true)
            {

            }
        }

        private void HeatCapacityButton_Click(object sender, RoutedEventArgs e)
        {
            var check = "HeatCapacity";
            var param = new AdditionalParam(check, _liquid);
            if (param.ShowDialog() == true)
            {
                _liquid.HeatCapacity = param.ParamBox.Text;

            }
        }
    }
}
