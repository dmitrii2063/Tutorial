﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model.ListsModels;
using TraceCalc.Model;
using System.IO;

namespace TraceCalc.View.WindowsForEnvironment
{
    /// <summary>
    /// Логика взаимодействия для Add_Environment.xaml
    /// </summary>
    public partial class AddAndEdit_Environment : Window
    {
        private Areas _area;
        public Areas NewArea { get; private set; }

        public AddAndEdit_Environment()
        {
            InitializeComponent();
            LoadParamForEditWindow(null); 
        }

        public AddAndEdit_Environment(Areas area)
        {
            _area = area;
            InitializeComponent();
            LoadParamForEditWindow(_area);
        }

        private void LoadParamForEditWindow(Areas area)
        {
            AreaTextBox.Text = area?.AreaName ?? "";
        }

        private void AreaOkButton_Click(object sender, RoutedEventArgs e)
        {
            var areaName = AreaTextBox.Text.Trim();

            if (string.IsNullOrEmpty(areaName))
            {
                MessageBox.Show("Имя области не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return; 
            }

            NewArea = new Areas
            {
                AreaName = areaName
            };


            if (_area == null)
            {
                Save(NewArea);
            }
            else
            {
                Update(_area, NewArea);
            }

            DialogResult = true;
            Close();
        }

        private void Save(Areas area)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure generalCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                generalCollection = new GeneralStructure
                {
                    Areas = new List<Areas>() 
                };
            }

            generalCollection.Areas.Add(area);
            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

        private void Update(Areas existingArea, Areas newArea)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            var generalCollection = JsonConvert.DeserializeObject<GeneralStructure>(File.ReadAllText(filePath));

            var areaToUpdate = generalCollection.Areas.FirstOrDefault(a => a.AreaName == existingArea.AreaName);
            if (areaToUpdate != null)
            {
                areaToUpdate.AreaName = newArea.AreaName; 
            }

            string updatedJson = JsonConvert.SerializeObject(generalCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

        private void AreaCancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
