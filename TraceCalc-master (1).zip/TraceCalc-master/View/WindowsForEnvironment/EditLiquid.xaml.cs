﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model.ListsModels;
using TraceCalc.Model;
using System.IO;
using System.Collections.ObjectModel;

namespace TraceCalc.View.WindowsForEnvironment
{
    /// <summary>
    /// Логика взаимодействия для EditLiquid.xaml
    /// </summary>
    public partial class EditLiquid : Window
    {
        public Action LiquidChanged;
        public EditLiquid()
        {
            InitializeComponent();
            LoadLiquids();
        }
        private void LoadLiquids()
        {
            LiquidDataGrid.ItemsSource = Config.Config.Instance.Liquids;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var liquidPropertiesWindow = new AddAndEdit_Liquid();
            if (liquidPropertiesWindow.ShowDialog() == true)
            {
                var newLiquid = liquidPropertiesWindow.NewLiquid;
                if (newLiquid != null)
                {
                    Config.Config.Instance.Liquids.Add(newLiquid);
                    LiquidDataGrid.ItemsSource = null;
                    LiquidDataGrid.ItemsSource = Config.Config.Instance.Liquids;
                    LiquidDataGrid.Items.Refresh();
                    LiquidChanged?.Invoke();
                }
            }
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = LiquidDataGrid.SelectedItem;

            if (selectedItem != null)
            {
                var liquidItem = selectedItem as Liquids;

                var editWindow = new AddAndEdit_Liquid(liquidItem);
                if (editWindow.ShowDialog() == true)
                {
                    var editedLiquid = editWindow.NewLiquid;

                    if (editedLiquid != null)
                    {
                        int index = Config.Config.Instance.Liquids.IndexOf(liquidItem);
                        if (index >= 0)
                        {
                            Config.Config.Instance.Liquids[index] = editedLiquid;
                        }

                        LiquidDataGrid.ItemsSource = null;
                        LiquidDataGrid.ItemsSource = Config.Config.Instance.Liquids;
                        LiquidChanged?.Invoke();
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedLiquid = LiquidDataGrid.SelectedItem as Liquids;

            if (selectedLiquid == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
                return;
            }

            MessageBoxResult answer = MessageBox.Show(@"Вы точно хотите удалить эту запись?",
                                                        "Подтверждение удаления",
                                                        MessageBoxButton.YesNo,
                                                        MessageBoxImage.Warning);

            if (answer == MessageBoxResult.Yes)
            {
                DeleteSelectedRow(selectedLiquid);
                Config.Config.Instance.Liquids.Remove(selectedLiquid);
                LiquidDataGrid.ItemsSource = null;
                LiquidDataGrid.ItemsSource = Config.Config.Instance.Liquids;
                LiquidDataGrid.Items.Refresh();
                LiquidChanged?.Invoke();
            }
            else
            {
                return;
            }

        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void DeleteSelectedRow(Liquids liquid)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    Areas = new List<Areas>(),
                    Liquids = new List<Liquids>()
                };
            }

            var liquidToDelete = pipesCollection.Liquids.FirstOrDefault(x => x.NameOfLiquid == liquid.NameOfLiquid);
            if (liquidToDelete == null)
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }
            pipesCollection.Liquids.Remove(liquidToDelete);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);

        }

    }
}
