﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;

namespace TraceCalc.View
{
    /// <summary>
    /// Логика взаимодействия для EditPipes.xaml
    /// </summary>
    public partial class EditPipes : Window
    {
        public event Action MainEditPipe;

        public EditPipes()
        {
            InitializeComponent();
            LoadPipes();
        }

        private void LoadPipes()
        {
            PipesDataGrid.ItemsSource = Config.Config.Instance.Pipes;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var pipePropertiesWindow = new Add_Pipe();
            if (pipePropertiesWindow.ShowDialog() == true)
            {
                var newPipe = pipePropertiesWindow.NewPipe;
                if (newPipe != null)
                {
                    Config.Config.Instance.Pipes.Add(newPipe);
                    PipesDataGrid.ItemsSource = null;
                    PipesDataGrid.ItemsSource = Config.Config.Instance.Pipes;
                    MainEditPipe?.Invoke();
                }

            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = PipesDataGrid.SelectedItem;

            if (selectedItem != null)
            {
                var pipeItem = selectedItem as Pipes;

                var editWindow = new Edit_Pipe(pipeItem);
                if (editWindow.ShowDialog() == true)
                {
                    PipesDataGrid.ItemsSource = null;
                    PipesDataGrid.ItemsSource = Config.Config.Instance.Pipes;
                    PipesDataGrid.Items.Refresh();
                    MainEditPipe?.Invoke();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedPipe = PipesDataGrid.SelectedItem as Pipes;

            if (selectedPipe == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
                return;
            }

            MessageBoxResult answer = MessageBox.Show(@"Вы точно хотите удалить эту запись?",
                                                        "Подтверждение удаления",
                                                        MessageBoxButton.YesNo,
                                                        MessageBoxImage.Warning);

            if(answer == MessageBoxResult.Yes)
            {
                DeleteSelectedRow(selectedPipe);
                Config.Config.Instance.Pipes.Remove(selectedPipe);
                PipesDataGrid.ItemsSource = null;
                PipesDataGrid.ItemsSource = Config.Config.Instance.Pipes;
                PipesDataGrid.Items.Refresh();
                MainEditPipe?.Invoke();
            }
            else
            {
                return;
            }

        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void DeleteSelectedRow(Pipes pipe)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs()
                };
            }

            var pipeToDelete = pipesCollection.Pipes.FirstOrDefault(x => x.Name == pipe.Name);
            if (pipeToDelete == null)
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }
            pipesCollection.Pipes.Remove(pipeToDelete);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);

        }
    }

}
