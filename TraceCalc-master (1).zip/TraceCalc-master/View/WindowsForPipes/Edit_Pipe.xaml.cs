﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;
using static TraceCalc.View.Add_Pipe;

namespace TraceCalc.View
{
    /// <summary>
    /// Логика взаимодействия для Edit_Pipe.xaml
    /// </summary>
    public partial class Edit_Pipe : Window
    {
        private Pipes _pipe;
        public Edit_Pipe(Pipes pipe)
        {
            _pipe = pipe;
            InitializeComponent();
            LoadParamForEditWindow(_pipe);
        }

        private void LoadParamForEditWindow(Pipes pipe)
        {
            IdTextBox.Text = pipe.Name;
            TypeComboBox.Text = pipe.TypeOfMaterial;
            DescriptionTextBox.Text = pipe.Description;
            HeatCapacity.Text = pipe.HeatCapacity;
            Density.Text = pipe.Density;
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs()
                };
            }

            var pipeToUpdate = pipesCollection.Pipes.FirstOrDefault(x => x.Name == _pipe.Name);
            if(pipeToUpdate != null)
            {
                pipeToUpdate.Name = IdTextBox.Text;
                pipeToUpdate.TypeOfMaterial = TypeComboBox.Text;
                pipeToUpdate.Description = DescriptionTextBox.Text;
                pipeToUpdate.Density = Density.Text;
                pipeToUpdate.HeatCapacity = HeatCapacity.Text;

                string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
                File.WriteAllText(filePath, updatedJson);
                MessageBox.Show("Данные успешно обновлены!");
                AcceptChanges(pipeToUpdate);
            }
            else
            {
                MessageBox.Show("Труба с таким именем не найдена.");
            }
            
            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void AcceptChanges(Pipes pipe)
        {
            _pipe.Name = pipe.Name;
            _pipe.TypeOfMaterial = pipe.TypeOfMaterial;
            _pipe.Description = pipe.Description;
            _pipe.Density = pipe.Density;
            _pipe.HeatCapacity = pipe.HeatCapacity;
        }

    }
}
