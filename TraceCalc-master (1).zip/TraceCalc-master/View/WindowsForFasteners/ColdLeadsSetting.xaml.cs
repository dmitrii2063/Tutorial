﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TraceCalc.View.WindowsForFasteners
{
    /// <summary>
    /// Логика взаимодействия для ColdLeadsSetting.xaml
    /// </summary>
    public partial class ColdLeadsSetting : Window
    {
        public ColdLeadsSetting()
        {
            InitializeComponent();
            Load();
        }
        private void Load()
        {
            var groupHeatCable = Config.Config.Instance.HeatCables;
            if (groupHeatCable != null)
            {
                foreach (var group in groupHeatCable)
                {
                    ChoiseGroupHeatCable.Items.Add(new ComboBoxItem { Content = group.HeatCablesGroupName });
                }
            }
        }
        private void OkButtonClick(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void UseColdLeadWithOneCircle_Checked(object sender, RoutedEventArgs e)
        {
            ChoiseColdLeadCheckBox.IsChecked = false;
            LenghtB.IsChecked = false;
        }

        private void UseColdLeadWithOneCircle_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void ChoiseGroupHeatCable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Очищаем комбобоксы при изменении выбора группы
            ChoiseHeatCable.Items.Clear();

            // Получаем выбранный элемент и проверяем его
            var selectedGroupItem = ChoiseGroupHeatCable.SelectedItem as ComboBoxItem;
            if (selectedGroupItem == null) return;

            // Получаем текст выбранной группы
            var selectedGroup = selectedGroupItem.Content.ToString();

            var config = Config.Config.Instance;

            // Находим соответствующую группу кабелей
            var selectedCablesGroup = config.HeatCables.FirstOrDefault(group => group.HeatCablesGroupName == selectedGroup);
            // Если группа найдена, заполняем комбобокс кабелей
            if (selectedCablesGroup != null)
            {
                foreach (var cable in selectedCablesGroup.HeatCablesName)
                {
                    ChoiseHeatCable.Items.Add(new ComboBoxItem { Content = cable.Name });
                }
                foreach(var seal in selectedCablesGroup.Seals)
                {
                    ChoiseSeal.Items.Add(new ComboBoxItem { Content = seal.NameOfSeal });
                }
               
            }
        }

    }
}
