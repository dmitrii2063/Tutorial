﻿using System;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TraceCalc.View.WindowsForFasteners
{
    /// <summary>
    /// Логика взаимодействия для FastenerSettings.xaml
    /// </summary>
    public partial class FastenerSettings : Window
    {
        private string _nutrition;
        public FastenerSettings(string nutrition)
        {
            _nutrition = nutrition;
            InitializeComponent();
            LoadParam(_nutrition);
        }
        private void LoadParam(string nutrition) 
        {
            NutritionName.Text = nutrition;
        }



        private void OkButtonClick(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButtonClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        private void CountCableGroups_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateOverallLayingCoeff();
        }

        private void Laying_Changed(object sender, RoutedEventArgs e)
        {
            UpdateOverallLayingCoeff();
        }
        private void UpdateOverallLayingCoeff()
        {
            // Проверяем наличие выбранного элемента в ComboBox
            if (CountCableGroups.SelectedItem is ComboBoxItem selectedItem &&
                int.TryParse(selectedItem.Content.ToString(), out int count) &&
                int.TryParse(LayingСoeff.Text, out int koef))
            {
                // Если оба значения успешно получены, обновляем текст общего коэффициента
                OverallLayingСoeff.Text = (count * koef).ToString();
            }
            else
            {
                // Если преобразование не удалось, можно установить значение по умолчанию или очистить
                OverallLayingСoeff.Text = string.Empty; // Или 0, в зависимости от ваших предпочтений
            }
        }
    }
}
