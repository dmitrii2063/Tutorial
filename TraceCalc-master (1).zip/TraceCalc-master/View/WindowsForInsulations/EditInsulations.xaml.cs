﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model.ListsModels;
using TraceCalc.Model;
using TraceCalc.View.WindowsForInsulations;
using System.IO;

namespace TraceCalc.View
{
    /// <summary>
    /// Логика взаимодействия для Edit_Valves.xaml
    /// </summary>
    public partial class EditInsulations : Window
    {
        public event Action InsulationUpdated;
        public EditInsulations()
        {
            InitializeComponent();
            LoadValvesAndSupports();
        }

        private void LoadValvesAndSupports()
        {
            InsulationDataGrid.ItemsSource = Config.Config.Instance.ThermalInsulations;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var newInsulationWindow = new Add_Insulation();
            if (newInsulationWindow.ShowDialog() == true)
            {
                var newInsulation = newInsulationWindow.NewInsulation;
                if (newInsulation != null)
                {
                    Config.Config.Instance.ThermalInsulations.Add(newInsulation);
                    InsulationDataGrid.ItemsSource = null;
                    InsulationDataGrid.ItemsSource = Config.Config.Instance.ThermalInsulations;
                    InsulationUpdated?.Invoke();
                }
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = InsulationDataGrid.SelectedItem;

            if (selectedItem != null)
            {
                var insulationItem = selectedItem as ThermalInsulation;

                var editWindow = new Edit_Insulation(insulationItem);
                if (editWindow.ShowDialog() == true)
                {
                    InsulationDataGrid.ItemsSource = null;
                    InsulationDataGrid.ItemsSource = Config.Config.Instance.ThermalInsulations;
                    InsulationDataGrid.Items.Refresh();
                    InsulationUpdated?.Invoke();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для редактирования.");
                return;
            }

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {

            var selectedInsulation = InsulationDataGrid.SelectedItem as ThermalInsulation;

            if (selectedInsulation == null)
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
                return;
            }

            MessageBoxResult answer = MessageBox.Show(@"Вы точно хотите удалить эту запись?",
                                                        "Подтверждение удаления",
                                                        MessageBoxButton.YesNo,
                                                        MessageBoxImage.Warning);

            if (answer == MessageBoxResult.Yes)
            {
                DeleteSelectedRow(selectedInsulation);
                Config.Config.Instance.ThermalInsulations.Remove(selectedInsulation);
                InsulationDataGrid.ItemsSource = null;
                InsulationDataGrid.ItemsSource = Config.Config.Instance.ThermalInsulations;
                InsulationDataGrid.Items.Refresh();
                InsulationUpdated?.Invoke();
            }
            else
            {
                return;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            InsulationDataGrid.ItemsSource = null;
            InsulationDataGrid.ItemsSource = Config.Config.Instance.ThermalInsulations;
            InsulationDataGrid.Items.Refresh();
            this.Close();
        }

        private void DeleteSelectedRow(ThermalInsulation insulation)
        {

            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    ThermalInsulations = new List<ThermalInsulation>()
                };
            }

            var insulationToDelete = pipesCollection.ThermalInsulations.FirstOrDefault(x => x.Layer == insulation.Layer);
            if (insulationToDelete == null)
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }
            pipesCollection.ThermalInsulations.Remove(insulationToDelete);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);

        }
    }
}
