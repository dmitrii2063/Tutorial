﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;

namespace TraceCalc.View
{
    /// <summary>
    /// Логика взаимодействия для Add_Valve.xaml
    /// </summary>
    public partial class Add_Insulation : Window
    {
        public ThermalInsulation NewInsulation { get; private set; }
        public Add_Insulation()
        {
            InitializeComponent();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            NewInsulation = new ThermalInsulation
            {
                Layer = IdTextBox.Text,
                Description = DescriptionTextBox.Text,
                MaxTemp = MaxTemp.Text,
                MinTemp = MinTemp.Text,
                Density = Density.Text,
                HeatCapacity = HeatCapacity.Text
            };
            Save(NewInsulation);
            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        private void Save(ThermalInsulation insulation)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    ThermalInsulations = new List<Model.ThermalInsulation>()
                };
            }

            pipesCollection.ThermalInsulations.Add(insulation);

            string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
            File.WriteAllText(filePath, updatedJson);
        }

    }
}

