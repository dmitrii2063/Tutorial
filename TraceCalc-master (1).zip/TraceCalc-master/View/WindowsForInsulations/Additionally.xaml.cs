﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;

namespace TraceCalc.View
{
    /// <summary>
    /// Логика взаимодействия для Additionally.xaml
    /// </summary>
    public partial class Additionally : Window
    {
        public event Action MainInsulationUpdated;
        public Additionally()
        {
            InitializeComponent();
            LoadThermalInsulation();
        }
        private void LoadThermalInsulation()
        {
            var thermalInsulateions = Config.Config.Instance.ThermalInsulations;
            if(thermalInsulateions != null)
            {
                foreach (var item in thermalInsulateions)
                {
                    OuterLayerComBox.Items.Add($"{item.Layer}\t{item.Description}");
                    InnerLayerComBox.Items.Add($"{item.Layer}\t{item.Description}");
                }
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void Edit_Valves_Button_Click(object sender, RoutedEventArgs e)
        {
            EditInsulations edit_Valves = new EditInsulations();
            edit_Valves.InsulationUpdated += () =>
            {
                InnerLayerComBox.ItemsSource = null;
                InnerLayerComBox.Items.Clear();
                InnerLayerComBox.ItemsSource = Config.Config.Instance.ThermalInsulations; 
                InnerLayerComBox.Items.Refresh();
                MainInsulationUpdated?.Invoke();
            };
            if (edit_Valves.ShowDialog() == true)
            {
                
            }
        }
        private void Edit_Valves_Button2_Click(object sender, RoutedEventArgs e)
        {
            EditInsulations edit_Valves = new EditInsulations();
            if (edit_Valves.ShowDialog() == true)
            {

            }
        }
    }
}
