﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;

namespace TraceCalc.View.WindowsForInsulations
{
    /// <summary>
    /// Логика взаимодействия для Edit_Isulation.xaml
    /// </summary>
    public partial class Edit_Insulation : Window
    {
        private ThermalInsulation _insulation;
        public Edit_Insulation(ThermalInsulation insulation)
        {
            _insulation = insulation;
            InitializeComponent();
            LoadParamForEditWindow(_insulation);
        }
        private void LoadParamForEditWindow(ThermalInsulation insulation)
        {
            IdTextBox.Text = insulation.Layer;
            DescriptionTextBox.Text = insulation.Description;
            MaxTemp.Text = insulation.MaxTemp;
            MinTemp.Text = insulation.MinTemp;
            Density.Text = insulation.Density;
            HeatCapacity.Text = insulation.HeatCapacity;
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            //string filePath = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var filePath = System.IO.Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            GeneralStructure pipesCollection;

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                pipesCollection = JsonConvert.DeserializeObject<GeneralStructure>(json);
            }
            else
            {
                pipesCollection = new GeneralStructure
                {
                    Pipes = new List<Pipes>(),
                    ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs(),
                    ThermalInsulations = new List<ThermalInsulation>()
                };
            }

            var insulationForUpdate = pipesCollection.ThermalInsulations.FirstOrDefault(x => x.Layer == _insulation.Layer);
            if (insulationForUpdate != null)
            {
                insulationForUpdate.Layer = _insulation.Layer;
                insulationForUpdate.Description = DescriptionTextBox.Text;
                insulationForUpdate.Density = Density.Text;
                insulationForUpdate.HeatCapacity = HeatCapacity.Text;
                insulationForUpdate.MaxTemp = MaxTemp.Text;
                insulationForUpdate.MinTemp = MinTemp.Text;

                string updatedJson = JsonConvert.SerializeObject(pipesCollection, Formatting.Indented);
                File.WriteAllText(filePath, updatedJson);
                MessageBox.Show("Данные успешно обновлены!");
                AcceptChanges(insulationForUpdate);
            }
            else
            {
                MessageBox.Show("Труба с таким именем не найдена.");
                return;
            }

            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        private void AcceptChanges(ThermalInsulation insulation)
        {
            _insulation.Layer = insulation.Layer;
            _insulation.Description = insulation.Description;
            _insulation.Density = insulation.Density;
            _insulation.HeatCapacity = insulation.HeatCapacity;
            _insulation.MaxTemp = insulation.MaxTemp;
            _insulation.MinTemp = insulation.MinTemp;
        }
    }
}
