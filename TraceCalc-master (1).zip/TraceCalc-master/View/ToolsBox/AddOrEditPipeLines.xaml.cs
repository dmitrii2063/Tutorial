﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TraceCalc.Model;
using static TraceCalc.Model.UserPipeLines;

namespace TraceCalc
{
    /// <summary>
    /// Логика взаимодействия для AddPipeLines.xaml
    /// </summary>
    public partial class AddOrEditPipeLines : Window
    {
        private bool isUpdatingLineComboBox = false;
        private UserPipeLines _pipeLine;
        private string currentFilePath;

        public AddOrEditPipeLines(string filePath)
        {
            InitializeComponent();
            LoadParamForEditWindow(null);
            InitializeLineTypeComboBox();
            currentFilePath = filePath;
        }
        public AddOrEditPipeLines(UserPipeLines userPipe, string filePath)
        {
            _pipeLine = userPipe;
            currentFilePath = filePath;
            InitializeComponent();
            LoadParamForEditWindow(_pipeLine);
        }
        private void InitializeLineTypeComboBox()
        {
            LineTypeComboBox.Items.Clear();
            LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Основная" });
            LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Отвлетление" });

            if (LineTypeComboBox.Items.Count > 0)
            {
                LineTypeComboBox.SelectedIndex = 0; 
            }
        }
        private void LoadParamForEditWindow(UserPipeLines userPipe)
        {
            NameLineTextBox.Text = userPipe?.NameLine ?? "";
            SectionTextBox.Text = userPipe?.Section ?? "";
            LineTypeComboBox.Text = userPipe?.LineType ?? "";
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            var pipLineName = NameLineTextBox.Text.Trim();
            if (string.IsNullOrEmpty(pipLineName))
            {
                MessageBox.Show("Имя области не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var parameterValue = new UserPipeLines()
            {
                NameLine = NameLineTextBox.Text,
                Section = SectionTextBox.Text,
                LineType = LineTypeComboBox.Text,
                Parameters = new Param()
                {
                    Pipe = new Pipes(),
                    Insulation = new ThermalInsulation(),
                    AdditionalParamForPipe = new AdditionalParamForPipe(),
                    TempParamForPipe = new TempParamForPipe(),
                    NutritionParamForPipe = new NutritionParamForPipe(),
                    ThermalInsulationForPipe = new ThermalInsulationForPipe(),
                    Area = new Areas(),
                    Liquid = new Liquids(),
                    Location = new Location() { InDoor = false, OutDoor = false },
                    ClassZone = new ClassZone() { Normal = false, SetTclassEquipment = false },
                    NutritioComponentParam = new NutritioComponentParam(),
                    EndComponentParam = new EndComponentParam(),
                    Panels = new Panels(),
                    HeatCableParam = new HeatCableParam() { SetFastener = false, SetKoef=false, Spiral=false },
                }
            };

            if (parameterValue == null)
            {
                MessageBox.Show("Пожалуйста, введите значение параметра.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_pipeLine != null)
            {
                Update(_pipeLine, parameterValue, currentFilePath);
            }
            else
            {
                Save(parameterValue, currentFilePath);
            }

            DialogResult = true;
            Close();
        }
        private void Update(UserPipeLines existingPipeLine, UserPipeLines updatedPipeLine, string filepath)
        {
            var jsonData = File.ReadAllText(filepath);
            var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonData);
            List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
            if (jsonObject != null && jsonObject.UserPipeLines != null)
            {
                userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
            }
            var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == _pipeLine.NameLine);
            if (pipeLineToEdit != null)
            {
                pipeLineToEdit.NameLine = updatedPipeLine.NameLine;
                pipeLineToEdit.Section = updatedPipeLine.Section;
                pipeLineToEdit.LineType = updatedPipeLine.LineType;
            }
            var updatedJsonObject = new
            {
                UserPipeLines = userPipeLinesList
            };
            var updatedJsonString = JsonConvert.SerializeObject(updatedJsonObject, Formatting.Indented);
            File.WriteAllText(filepath, updatedJsonString);

        }
        private void Save(UserPipeLines userPipe, string filePath)
        {
            string fileName = filePath;
            try
            {
                List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                if (File.Exists(fileName))
                {
                    var jsonString = File.ReadAllText(fileName);
                    var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                    if (jsonObject != null && jsonObject.UserPipeLines != null)
                    {
                        userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                    }
                }
                userPipeLinesList.Add(userPipe);
                var updatedJsonObject = new
                {
                    UserPipeLines = userPipeLinesList
                };
                var updatedJsonString = JsonConvert.SerializeObject(updatedJsonObject, Formatting.Indented);
                File.WriteAllText(fileName, updatedJsonString);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении файла: {ex.Message}");
            }
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void LineTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (isUpdatingLineComboBox) return;

            if (LineTypeComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string selectedContent = selectedItem.Content.ToString();

                isUpdatingLineComboBox = true;

                if (selectedContent == "Основная")
                {
                    LineTypeComboBox.Items.Clear();
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Основная" });
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Отвлетление" });


                    LineTypeComboBox.SelectedIndex = 0;
                    LineTypeImage.Source = new BitmapImage(new Uri("pack://application:,,,/Images/Main.png"));
                }

                else if (selectedContent == "Отвлетление")
                {
                    LineTypeComboBox.Items.Clear();
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Силовая параллельная" });
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Силовая разветвление" });
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Силовая по центру" });
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Петля" });
                    LineTypeComboBox.Items.Add(new ComboBoxItem { Content = "Основная" });

                    LineTypeComboBox.SelectedIndex = 0;
                    LineTypeImage.Source = new BitmapImage(new Uri("pack://application:,,,/Images/PowerParallel.png"));
                }
                else if (selectedContent == "Петля")
                {
                    LineTypeImage.Source = new BitmapImage(new Uri("pack://application:,,,/Images/Loop.png"));
                }
                else if (selectedContent == "Силовая разветвление")
                {
                    LineTypeImage.Source = new BitmapImage(new Uri("pack://application:,,,/Images/PowerBranch.png"));
                }
                else if (selectedContent == "Силовая по центру")
                {
                    LineTypeImage.Source = new BitmapImage(new Uri("pack://application:,,,/Images/PowerCentral.png"));
                }
                isUpdatingLineComboBox = false;
            }

        }
    }
}
