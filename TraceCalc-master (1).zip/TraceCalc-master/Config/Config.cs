﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Media3D;
using TraceCalc.Model;

namespace TraceCalc.Config
{
    public class Config
    {
        private static Config _instance;

        private Config()
        {
            Load();
        }

        public static Config Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Config();
                }
                return _instance;
            }
        }

        public List<Pipes> Pipes { get; set; }
        public ValvesAndSupportsAndFlangs ValvesAndSupportsAndFlangs { get; set; }
        public List<ThermalInsulation> ThermalInsulations { get; set; }
        public List<Areas> Areas { get; set; }
        public List<Liquids> Liquids { get; set; }
        public List<Fasteners> Fasteners { get; set; }
        public List<HeatCables> HeatCables { get; set; }
        public List<Panels> Panels { get; set; }
        public List<Sensor> Sensors { get; set; }
        public List<LocalControl> LocalControls { get; set; }

        private void  Load()
        {

            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var path = Path.Combine(baseDirectory, "..", "..", "Db", "data.json");

            //var path = "C:\\Users\\npiskarev\\Desktop\\HomeWork\\TraceCalc\\Db\\data.json";

            if (!File.Exists(path))
            {
                throw new FileNotFoundException("Конфигурационный файл не найден", path);
            }

            var json = File.ReadAllText(path);
            var configData = JsonConvert.DeserializeObject<ConfigData>(json);
            if (configData != null)
            {
                Pipes = configData.Pipes;
                ValvesAndSupportsAndFlangs = configData.ValvesAndSupportsAndFlangs;
                ThermalInsulations = configData.ThermalInsulations;
                Areas = configData.Areas;
                Liquids = configData.Liquids;
                Fasteners = configData.Fasteners;
                HeatCables = configData.HeatCables;
                Panels = configData.Panels;
                Sensors = configData.Sensors;
                LocalControls = configData.LocalControls;
            }
            else
            {
                MessageBox.Show("Не удалось загрузить трубы из конфигурационного файла.");
                Pipes = new List<Pipes>();
                ValvesAndSupportsAndFlangs = new ValvesAndSupportsAndFlangs();
                ThermalInsulations = new List<ThermalInsulation>();
                Areas = new List<Areas>();
                Liquids = new List<Liquids>();
                Fasteners = new List<Fasteners>();
                HeatCables = new List<HeatCables>();
                Panels = new List<Panels>();
                Sensors = new List<Sensor>();
                LocalControls = new List<LocalControl>();
            }

        }
        private class ConfigData
        {
            public List<Pipes> Pipes { get; set; }
            public ValvesAndSupportsAndFlangs ValvesAndSupportsAndFlangs { get; set; }
            public List<ThermalInsulation> ThermalInsulations { get; set; }
            public List<Areas> Areas { get; set; }
            public List<Liquids> Liquids { get; set; }
            public List<Fasteners> Fasteners { get; set; }
            public List<HeatCables> HeatCables { get; set; }
            public List<Panels> Panels { get; set; }
            public List<Sensor> Sensors { get; set; }
            public List<LocalControl> LocalControls { get; set; }
        }
    }
}
