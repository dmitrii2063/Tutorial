﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Xml.Linq;
using TraceCalc.Config;
using TraceCalc.Model;
using TraceCalc.Model.ListsModels;
using TraceCalc.View;
using TraceCalc.View.WindowsForEnvironment;
using TraceCalc.View.WindowsForFasteners;
using TraceCalc.View.WindowsForInsulations;
using TraceCalc.View.WindowsForPnales;
using TraceCalc.View.WindowsForProject;
using static TraceCalc.Model.UserPipeLines;

namespace TraceCalc
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isProcessingSelectionChange = false;
        private bool isUpdatingLineComboBox = false;
        private string currentFilePath;
        public MainWindow()
        {
            InitializeComponent();
            Load();
        }

        private void Load()
        {
            var config = Config.Config.Instance;
            ClearComboBoxes();

            AddItemsToComboBox(Pipes, config.Pipes.Select(pipe => $"{pipe.Name}\t{pipe.Description}"));
            AddItemsToComboBox(ThermalIsolationCombobox, config.ThermalInsulations.Select(insulation => insulation.Layer));
            AddItemsToComboBox(AreaComboBox, config.Areas.Select(area => area.AreaName));
            AddItemsToComboBox(LiquidComboBox, config.Liquids.Select(liquid => liquid.NameOfLiquid));
            AddItemsToComboBox(SetFastenersComboBox, config.Fasteners.Select(fastener => fastener.FastenerName));
            AddItemsToComboBox(HeatCablesGroupName, config.HeatCables.Select(cables => cables.HeatCablesGroupName));
            HeatCablesGroupName.SelectionChanged += HeatCablesGroupName_SelectionChanged;
            AddItemsToComboBox(Panels, config.Panels.Select(x => x.NameOfPanel));
            AddItemsToComboBox(Sensors, config.Sensors.Select(x => x.SensorName));
            AddItemsToComboBox(Sensors2, config.Sensors.Select(x => x.SensorName));

        }
        private void ClearComboBoxes()
        {
            Pipes.Items.Clear();
            ThermalIsolationCombobox.Items.Clear();
            LiquidComboBox.Items.Clear();
            AreaComboBox.Items.Clear();
            LiquidComboBox.Items.Clear();
            SetFastenersComboBox.Items.Clear();
            HeatCablesGroupName.Items.Clear();
            HeatCablesName.Items.Clear();
            Panels.Items.Clear();
            Sensors.Items.Clear();
            Sensors2.Items.Clear();
        }
        private void AddItemsToComboBox(ComboBox comboBox, IEnumerable<string> items)
        {
            foreach (var item in items)
            {
                comboBox.Items.Add(item);
            }
        }
        private void EditPipes_Click(object sender, RoutedEventArgs e)
        {
            EditPipes editPipes = new EditPipes();
            editPipes.MainEditPipe += () =>
            {
                Pipes.Items.Clear();
                Pipes.ItemsSource = null;
                AddItemsToComboBox(Pipes, Config.Config.Instance.Pipes.Select(pipe => $"{pipe.Name}\t{pipe.Description}"));
                Pipes.Items.Refresh();
            };
            if (editPipes.ShowDialog() == true)
            {

            }
        }
        private void ValvesAndSupports_Click(object sender, RoutedEventArgs e)
        {
            ValvesAndSupports show = new ValvesAndSupports();
            if (show.ShowDialog() == true)
            {

            }
        }
        private void Additionally_Click(object sender, RoutedEventArgs e)
        {
            Additionally additionally = new Additionally();
            additionally.MainInsulationUpdated += () =>
            {
                ThermalIsolationCombobox.Items.Clear();
                ThermalIsolationCombobox.ItemsSource = null;
                AddItemsToComboBox(ThermalIsolationCombobox, Config.Config.Instance.ThermalInsulations.Select(insulation => insulation.Layer));
                ThermalIsolationCombobox.Items.Refresh();
            };
            if (additionally.ShowDialog() == true)
            {

            }
        }
        private void ThermalInsulationEditButton_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new EditInsulations();
            editWindow.InsulationUpdated += () =>
            {
                ThermalIsolationCombobox.Items.Clear();
                ThermalIsolationCombobox.ItemsSource = null;
                AddItemsToComboBox(ThermalIsolationCombobox, Config.Config.Instance.ThermalInsulations.Select(insulation => insulation.Layer));
                ThermalIsolationCombobox.Items.Refresh();
            };
            if (editWindow.ShowDialog() == true)
            {

            }
        }
        private void EditArea_Click(object sender, RoutedEventArgs e)
        {
            var editArea = new EditArea();
            editArea.AreaChanged += () =>
            {
                AreaComboBox.Items.Clear();
                AreaComboBox.ItemsSource = null;
                AddItemsToComboBox(AreaComboBox, Config.Config.Instance.Areas.Select(area => area.AreaName));
                AreaComboBox.Items.Refresh();
            };
        }
        private void EditLiquid_Click(object sender, RoutedEventArgs e)
        {
            var editLiquid = new EditLiquid();
            editLiquid.LiquidChanged += () =>
            {
                LiquidComboBox.Items.Clear();
                LiquidComboBox.ItemsSource = null;
                AddItemsToComboBox(LiquidComboBox, Config.Config.Instance.Liquids.Select(liquid => liquid.NameOfLiquid));
                LiquidComboBox.Items.Refresh();
            };
            if (editLiquid.ShowDialog() == true)
            {

            }
        }
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void HeatCablesGroupName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            HeatCablesName.Items.Clear();

            var selectedGroup = HeatCablesGroupName.SelectedItem as string;
            var config = Config.Config.Instance;

            var selectedCablesGroup = config.HeatCables.FirstOrDefault(group => group.HeatCablesGroupName == selectedGroup);

            if (selectedCablesGroup != null)
            {
                foreach (var cable in selectedCablesGroup.HeatCablesName)
                {
                    HeatCablesName.Items.Add(new ComboBoxItem { Content = cable.Name });
                }
            }
        }
        private void ShowProjectSettings(object sender, RoutedEventArgs e)
        {
            ProjSettings projSettings = new ProjSettings();
            bool? result = projSettings.ShowDialog();

            if (result == true)
            {
                // Получаем список выбранных труб
                if (projSettings.Tag is List<string> selectedPipes)
                {
                    Pipes.Items.Clear();
                    Pipes.ItemsSource = null;
                    foreach (var pipe in selectedPipes)
                    {
                        var pipeAdd = Config.Config.Instance.Pipes.FirstOrDefault(x => x.Name == pipe);
                        if (pipeAdd != null)
                        {
                            Pipes.Items.Add($"{pipeAdd.Name}\t{pipeAdd.Description}");
                        }
                    }
                }
            }
        }
        private void FastenerSettings_Click(object sender, RoutedEventArgs e)
        {
            var fastener = Nutrition.Text;
            var show = new FastenerSettings(fastener);
            show.ShowDialog();
        }
        private void ColdLeadSettingsClick(object sender, RoutedEventArgs e)
        {
            var show = new ColdLeadsSetting();
            show.ShowDialog();
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Открыть файл"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                var filePath = openFileDialog.FileName;
                currentFilePath = filePath;
                string json = File.ReadAllText(filePath);
                LoadFromJson(json);
            }
            UpdateTabControlState(true);
        }
        private void LoadFromJson(string json)
        {
            var userPipeLinesData = JsonConvert.DeserializeObject<UserPipeLinesData>(json);

            MyTreeView.Items.Clear();

            if (userPipeLinesData?.UserPipeLines != null)
            {
                foreach (var pipeline in userPipeLinesData.UserPipeLines)
                {
                    TreeViewItem newItem = new TreeViewItem { Header = pipeline.NameLine };
                    MyTreeView.Items.Add(newItem);
                }
                UpdateTabControlState(true);
            }
        }
        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem != null && selectedItem.HasItems == false)
            {
                var fileName = currentFilePath;
                var jsonString = File.ReadAllText(fileName);
                var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                if (jsonObject != null && jsonObject.UserPipeLines != null)
                {
                    userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                }
                var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
                if (pipeLineToEdit == null)
                {
                    MessageBox.Show($"Ошибка при измении файла");
                    return;
                }

                var pipeFromEdit = pipeLineToEdit.Parameters;
                if (pipeFromEdit == null) return;

                string fullString = Pipes.Text;
                if (!string.IsNullOrEmpty(Pipes.Text))
                {
                    string[] parts = fullString.Split('\t');

                    if (parts.Length > 0)
                    {
                        var findPipe = Config.Config.Instance.Pipes.FirstOrDefault(p => p.Name == parts[0]);
                        if (findPipe != null)
                        {
                            pipeFromEdit.Pipe.Name = findPipe.Name;
                            pipeFromEdit.Pipe.Description = findPipe.Description;
                            pipeFromEdit.Pipe.Density = findPipe.Density;
                            pipeFromEdit.Pipe.TypeOfMaterial = findPipe.TypeOfMaterial;
                            pipeFromEdit.Pipe.HeatCapacity = findPipe.HeatCapacity;
                        }
                    }
                }
                UpdateAdditionalParam(pipeLineToEdit.Parameters.AdditionalParamForPipe);
                UpdateTempParam(pipeLineToEdit.Parameters.TempParamForPipe);
                UpdateNutrition(pipeLineToEdit.Parameters.NutritionParamForPipe);
                UpdateThermalIsolationForPipe(pipeLineToEdit.Parameters.ThermalInsulationForPipe);
                UpdateLocationParam(pipeLineToEdit.Parameters.Location);
                UpdateClassZoneParam(pipeLineToEdit.Parameters.ClassZone);
                UpdatePanelParam(pipeLineToEdit.Parameters.Panels);
                UpdateHeatCableParam(pipeLineToEdit.Parameters.HeatCableParam);
                UpdateIsolationParam(pipeLineToEdit.Parameters.Insulation);
                UpdateAreaParam(pipeLineToEdit.Parameters.Area);
                UpdateLiquidParam(pipeLineToEdit.Parameters.Liquid);
                UpdateNutritionComponentParam(pipeLineToEdit.Parameters.NutritioComponentParam);
                UpdateEndComponentParam(pipeLineToEdit.Parameters.EndComponentParam);

                jsonObject.UserPipeLines = JArray.FromObject(userPipeLinesList);
                string updatedJsonString = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);

                File.WriteAllText(fileName, updatedJsonString);
                //MessageBox.Show("Изменения успешно сохранены");
            }
        }
        private void CreateFile_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*";
            saveFileDialog.Title = "Сохранить файл как";

            if (saveFileDialog.ShowDialog() == true)
            {

                var newUserPipeLine = new UserPipeLinesData()
                {
                    UserPipeLines = new List<UserPipeLines>()
                    {
                        new UserPipeLines()
                        {
                            NameLine = "NewLine",
                            Parameters = new Param()
                            {
                                Pipe = new Pipes(),
                                Insulation = new ThermalInsulation(),
                                AdditionalParamForPipe = new AdditionalParamForPipe(),
                                TempParamForPipe = new TempParamForPipe(),
                                NutritionParamForPipe = new NutritionParamForPipe(),
                                ThermalInsulationForPipe = new ThermalInsulationForPipe(),
                                Area = new Areas(),
                                Liquid = new Liquids(),
                                Location = new Location() { InDoor = false, OutDoor = false },
                                ClassZone = new ClassZone() { Normal = false, SetTclassEquipment = false },
                                NutritioComponentParam = new NutritioComponentParam(),
                                EndComponentParam = new EndComponentParam(),
                                Panels = new Panels(),
                                HeatCableParam = new HeatCableParam() { SetFastener = false, SetKoef=false, Spiral=false },
                            }
                        }
                    }
                };
                MyTreeView.Items.Clear();
                TreeViewItem newItem = new TreeViewItem { Header = "NewLine" };
                MyTreeView.Items.Add(newItem);

                string fileName = saveFileDialog.FileName;
                currentFilePath = fileName;

                try
                {
                    var userPipeLinesList = new List<UserPipeLines>();
                    userPipeLinesList.AddRange(newUserPipeLine.UserPipeLines);

                    var jsonObject = new
                    {
                        UserPipeLines = userPipeLinesList
                    };

                    var jsonString = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                    File.WriteAllText(fileName, jsonString);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении файла: {ex.Message}");
                }
                finally
                {
                    UpdateTabControlState(true);
                }
            }
        }
        private void AddNewPipe_Click(object sender, RoutedEventArgs e)
        {
            Add_Click(sender, e);
        }
        private void AddNewCapacity_Click(object sender, RoutedEventArgs e)
        {

        }
        private void CopyRecord_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem != null && selectedItem.HasItems == false)
            {
                var fileName = currentFilePath;
                var jsonString = File.ReadAllText(fileName);
                var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                if (jsonObject != null && jsonObject.UserPipeLines != null)
                {
                    userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                }
                var pipeLineCurrent = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
                if (pipeLineCurrent == null)
                {
                    MessageBox.Show($"Ошибка при измении файла");
                    return;
                }
                var copyPipeLine = pipeLineCurrent;
                copyPipeLine.NameLine = $"{selectedItem.Header}_copy";

                TreeViewItem newItem = new TreeViewItem { Header = copyPipeLine.NameLine };

                TreeViewItem parentItem = FindParent(selectedItem);
                if (parentItem != null)
                {
                    parentItem.Items.Add(newItem);
                }

                userPipeLinesList.Add(copyPipeLine);

                var updatedJsonObject = new
                {
                    UserPipeLines = userPipeLinesList
                };

                var updatedJsonString = JsonConvert.SerializeObject(updatedJsonObject, Formatting.Indented);
                File.WriteAllText(fileName, updatedJsonString);

            }
        }
        private TreeViewItem FindParent(TreeViewItem item)
        {
            if (item == null) return null;

            // Проходим через все элементы в TreeView
            foreach (var parent in PipeLinesTree.Items.OfType<TreeViewItem>())
            {
                if (HasChild(parent, item))
                {
                    return parent;
                }
            }

            return null;
        }
        private bool HasChild(TreeViewItem parent, TreeViewItem child)
        {
            if (parent.Items.Contains(child))
            {
                return true;
            }

            foreach (var item in parent.Items.OfType<TreeViewItem>())
            {
                if (HasChild(item, child))
                {
                    return true;
                }
            }

            return false;
        }
        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            Delete_Click(sender, e);
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            AddOrEditPipeLines parameterWindow = new AddOrEditPipeLines(currentFilePath);
            if (parameterWindow.ShowDialog() == true)
            {
                string name = parameterWindow.NameLineTextBox.Text;
                string type = parameterWindow.LineTypeComboBox.Text;

                var selectedPipeLine = PipeLinesTree.SelectedItem as TreeViewItem;
                if (selectedPipeLine != null && type != "Основная")
                {
                    TreeViewItem newChildItem = new TreeViewItem { Header = name };
                    selectedPipeLine.Items.Add(newChildItem);
                }
                else
                {
                    TreeViewItem newItem = new TreeViewItem { Header = name };
                    MyTreeView.Items.Add(newItem);
                }
            }
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem != null && selectedItem.HasItems == false)
            {
                var pipeLineName = selectedItem.Header.ToString();
                var result = MessageBox.Show($"Вы уверены, что хотите удалить трубопровод '{pipeLineName}'?",
                              "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    var fileName = currentFilePath;
                    var jsonString = File.ReadAllText(fileName);
                    var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                    List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();

                    if (jsonObject != null && jsonObject.UserPipeLines != null)
                    {
                        userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                        userPipeLinesList.RemoveAll(pipeLine => pipeLine.NameLine == pipeLineName);
                        var updatedJsonObject = new
                        {
                            UserPipeLines = userPipeLinesList
                        };
                        var newJsonString = JsonConvert.SerializeObject(updatedJsonObject, Formatting.Indented);
                        File.WriteAllText(fileName, newJsonString);

                        UpdateTreeView(userPipeLinesList);
                    }
                }
            }
        }
        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            SaveFile_Click(sender, e);

            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem != null && selectedItem.HasItems == false)
            {
                var fileName = currentFilePath;
                var jsonString = File.ReadAllText(fileName);
                var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                if (jsonObject != null && jsonObject.UserPipeLines != null)
                {
                    userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                }
                var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
                if (pipeLineToEdit == null)
                {
                    MessageBox.Show($"Ошибка при измении файла");
                    return;
                }

                var pipeFromEdit = pipeLineToEdit.Parameters;
                if (pipeFromEdit == null) return;
                double thickness, insulation, diam, wallThickness, length, heatCapacity, temp, tempMinEnv;

                if (!double.TryParse(pipeFromEdit.ThermalInsulationForPipe.ThicknessIsolation, out thickness) ||
                    !double.TryParse(pipeFromEdit.Insulation.ThermalConductivity, out insulation) ||
                    !double.TryParse(pipeFromEdit.AdditionalParamForPipe.Diam, out diam) ||
                    !double.TryParse(pipeFromEdit.AdditionalParamForPipe.WallThickness, out wallThickness) ||
                    !double.TryParse(pipeFromEdit.AdditionalParamForPipe.Lenght, out length) ||
                    !double.TryParse(pipeFromEdit.Pipe.HeatCapacity, out heatCapacity) ||
                    !double.TryParse(pipeFromEdit.TempParamForPipe.SupportedTemp, out temp) ||
                    !double.TryParse(pipeFromEdit.TempParamForPipe.MinEnvironment, out tempMinEnv))
                {
                    MessageBox.Show("Ошибка в преобразовании данных. Проверьте входные параметры.");
                    return;
                }

                double rc = (1 / (2 * Math.PI * heatCapacity)) * Math.Log(diam / (diam - 2 * wallThickness)) + (2 / (3 * Math.PI * insulation)) * Math.Log((diam + 2 * thickness) / diam);
                int a = 0;
                double koefRez = 0;
                if (pipeFromEdit.Location.InDoor == true)
                    a = 10;
                if (pipeFromEdit.Location.OutDoor == true)
                    a = 30;
                if (diam < 100)
                    koefRez = 1.15;
                else
                    koefRez = 1.1;
                var r = (1000 / (a * 3.141 * (diam + 2 * thickness))) + rc;
                var rpot = (koefRez * (temp - tempMinEnv) / r);

                HeatLoss.Text = rpot.ToString("F2");
                HeatLoss.FontWeight = FontWeights.Bold;
                LabelDateToday.Content = DateTime.Today.ToString("d");
            }

            // Возвращаем фон кнопки к исходному состоянию
            Calculate.Background = new SolidColorBrush(Colors.White); // Или другой исходный цвет

            // Возвращаем цвет границы в исходное состояние
            var defaultBorderBrush = new SolidColorBrush(Colors.Gray); // Изначальный цвет границы
            Calculate.BorderBrush = defaultBorderBrush;

            // Отмена всех анимаций, если необходимо
            if (Calculate.BorderBrush is SolidColorBrush currentBrush)
            {
                currentBrush.BeginAnimation(SolidColorBrush.ColorProperty, null);
            }
        }
        private void ShowContextMenu_Click(object sender, RoutedEventArgs e)
        {
            ContextMenu contextMenu = TreeViewContextMenu; // Получаем контекстное меню
            contextMenu.IsOpen = true; // Открываем контекстное меню
        }
        
        
        private void UpdateTabControlState(bool enabled)
        {
            MyTabControl.IsEnabled = enabled;
            Add.IsEnabled = enabled;
            Delete.IsEnabled = enabled;
            SaveFile.IsEnabled = enabled;
            Calculate.IsEnabled = enabled;
            HeatCableBox.IsEnabled = enabled;
            foreach (var i in PipeLinesTree.ContextMenu.Items)
            {
                if (i is MenuItem menu)
                {
                    menu.IsEnabled = enabled;
                }
            }

        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateTabControlState(false);
        }
        private void ChangeUserPipeLine(object sender, RoutedEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem != null && selectedItem.HasItems == false)
            {
                var fileName = currentFilePath;
                var jsonString = File.ReadAllText(fileName);
                var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                if (jsonObject != null && jsonObject.UserPipeLines != null)
                {
                    userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                }
                var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
                if (pipeLineToEdit == null)
                {
                    MessageBox.Show($"Ошибка при измении файла");
                    return;
                }
                var show = new AddOrEditPipeLines(pipeLineToEdit, currentFilePath);
                if (show.ShowDialog() == true)
                {
                    selectedItem.Header = show.NameLineTextBox.Text;
                }
            }
        }
        private void UpdateTreeView(List<UserPipeLines> userPipeLinesList)
        {
            MyTreeView.Items.Clear();
            foreach (var pipeLine in userPipeLinesList)
            {
                TreeViewItem item = new TreeViewItem { Header = pipeLine.NameLine };
                MyTreeView.Items.Add(item);
            }
        }
        private void PipeLinesTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (isProcessingSelectionChange)
                return;

            if (selectedItem != null && selectedItem.HasItems == false)
            {
                isProcessingSelectionChange = true;
                try
                {
                    var fileName = currentFilePath;
                    if (!File.Exists(fileName)) return;
                    var jsonString = File.ReadAllText(fileName);
                    var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
                    List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
                    if (jsonObject != null && jsonObject.UserPipeLines != null)
                    {
                        userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
                    }
                    var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
                    if (pipeLineToEdit == null) return;
                    if (pipeLineToEdit.Parameters == null) return;
                    var pipe = pipeLineToEdit.Parameters.Pipe;

                    var addit_param = pipeLineToEdit.Parameters.AdditionalParamForPipe;
                    var temp_param = pipeLineToEdit.Parameters.TempParamForPipe;
                    var nutrition = pipeLineToEdit.Parameters.NutritionParamForPipe;
                    var thermIsolationAdd = pipeLineToEdit.Parameters.ThermalInsulationForPipe;
                    var area_param = pipeLineToEdit.Parameters.Area;
                    var liquid_param = pipeLineToEdit.Parameters.Liquid;
                    var location = pipeLineToEdit.Parameters.Location;
                    var classZone = pipeLineToEdit.Parameters.ClassZone;
                    var nutritionComponent = pipeLineToEdit.Parameters.NutritioComponentParam;
                    var endComponent = pipeLineToEdit.Parameters.EndComponentParam;
                    var panel = pipeLineToEdit.Parameters.Panels;
                    var heatCableParam = pipeLineToEdit.Parameters.HeatCableParam;

                    if (pipeLineToEdit == null)
                    {
                        MessageBox.Show($"Данный элемент не найден");
                        return;
                    }
                    NameOfLine.Text = pipeLineToEdit.NameLine;
                    Section.Text = pipeLineToEdit.Section;
                    TypeOfLine.Text = pipeLineToEdit.LineType;
                    Pipes.Text = pipeLineToEdit.Parameters.Pipe.Name;
                    Diam.SelectedItem = addit_param.Diam;
                    DiamBox.Text = addit_param.Diam;
                    WallThickness.Text = addit_param.WallThickness;
                    Lenght.Text = addit_param.Lenght;

                    SupportedTemp.Text = temp_param.SupportedTemp;
                    MinEnvironment.Text = temp_param.MinEnvironment;
                    MaxEnvironment.Text = temp_param.MaxEnvironment;
                    MaxImpactOnCable.Text = temp_param.MaxImpactOnCable;
                    MaxWorkingPipe.Text = temp_param.MaxWorkingPipe;
                    MaxAllowableProduct.Text = temp_param.MaxAllowableProduct;

                    Nutrition.Text = nutrition.Nutrition;
                    MaxCurrent.Text = nutrition.MaxCurrent;
                    Voltage.Text = nutrition.Voltage;
                    WorkingVoltageGrCable.Text = nutrition.WorkingVoltageGrCable;

                    var thermIsol = pipeLineToEdit.Parameters.Insulation;

                    ThermalIsolationCombobox.Text = thermIsol.Layer;

                    ThicknessIsolation.Text = thermIsolationAdd.ThicknessIsolation;

                    if (!string.IsNullOrEmpty(pipe.Name))
                    {
                        Pipes.SelectedIndex = Pipes.Items.Cast<string>()
                                     .ToList()
                                     .FindIndex(i => i.StartsWith(pipe.Name));
                    }

                    LiquidComboBox.Text = liquid_param.NameOfLiquid;
                    AreaComboBox.Text = area_param.AreaName;
                    SchemeForPipe.Text = location.SchemeForPipe;
                    WindSpeed.Text = location.WindSpeed;
                    ChimicalExposure.Text = location.ChimicalExposure;
                    HeatLossReserve.Text = location.HeatLossReserve;
                    ColdStartTemperature.Text = location.ColdStartTemperature;
                    Comm.Text = location.Comm;
                    OutDoor.IsChecked = location.OutDoor;
                    InDoor.IsChecked = location.InDoor;

                    if (classZone.Normal == true)
                    {
                        toggleZoneCheckBox.IsChecked = classZone.Normal;
                        Zone1.IsChecked = classZone.Zone1;
                        Zone2.IsChecked = classZone.Zone2;
                        Zone21.IsChecked = classZone.Zone21;
                        Zone22.IsChecked = classZone.Zone22;
                    }
                    if (classZone.SetTclassEquipment == true)
                    {
                        SetTclassEquipment.IsChecked = classZone.SetTclassEquipment;
                        SetAutoignitionTemperature.IsChecked = classZone.SetAutoignitionTemperature;
                        Tclass.Text = classZone.Tclass;
                    }
                    if (classZone.StabilizedСalculation == true)
                    {
                        toggleStab.IsChecked = classZone.StabilizedСalculation;
                        toggleTemp.IsChecked = classZone.UseATemperatureLimiter;
                        SettingTheControlDeviceLimit.Text = classZone.SettingTheControlDeviceLimit;
                    }

                    if (nutritionComponent != null)
                    {
                        TypeConnectionManualCheckBox.IsChecked = nutritionComponent.ConnectionTypeManualCheck;
                        TypeConnectionManual.Text = nutritionComponent.ConnectionTypeManual;
                        SelectAComponentToConnectCheckBox.IsChecked = nutritionComponent.SelectAComponentToConnectCheck;
                        SelectAComponentToConnect.Text = nutritionComponent.SelectAComponentToConnect;
                        GroundPlateCheck.IsChecked = nutritionComponent.GroundPlateCheck;
                        OutsidePipeCheck.IsChecked = nutritionComponent.OutsidePipeCheck;
                        BacklightCheck.IsChecked = nutritionComponent.BacklightCheck;
                        UnderInsulationCheck.IsChecked = nutritionComponent.UnderInsulationCheck;
                    }
                    if (endComponent != null)
                    {
                        EndConnectionTypeManualCheck.IsChecked = endComponent.EndConnectionTypeManualCheck;
                        EndConnectionTypeManual.Text = endComponent.EndConnectionTypeManual;
                        EndSelectAComponentToConnectCheck.IsChecked = endComponent.EndSelectAComponentToConnectCheck;
                        EndSelectAComponentToConnect.Text = endComponent.EndSelectAComponentToConnect;
                        EndGroundPlateCheck.IsChecked = endComponent.EndGroundPlateCheck;
                        EndBacklightCheck.IsChecked = endComponent.EndBacklightCheck;
                        EndUnderInsulationCheck.IsChecked = endComponent.EndUnderInsulationCheck;
                        EndOutsidePipeCheck.IsChecked = endComponent.EndOutsidePipeCheck;
                    }
                    if (panel != null)
                    {
                        Panels.Text = panel.NameOfPanel;
                        RegMethod.Text = panel.RegMethod;
                        Sensors.Text = panel.Sensor;
                        Sensors2.Text = panel.SecondSensor;
                    }
                    if (heatCableParam != null)
                    {
                        Category.Text = heatCableParam.Category;
                        Veins.Text = heatCableParam.Veins;
                        Spiral.IsChecked = heatCableParam.Spiral;
                        toggleKoef.IsChecked = heatCableParam.SetKoef;
                        toggleProj.IsChecked = heatCableParam.SetFastener;
                        HeatCablesGroupName.Text = heatCableParam.HeatCablesGroupName;
                        HeatCablesName.Text = heatCableParam.HeatCablesName;
                        SetFastenersComboBox.Text = heatCableParam.Fastener;
                    }
                }
                finally
                {
                    isProcessingSelectionChange = false;
                }
            }
        }
        private void TypeOfLine_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TypeOfLine.SelectedIndex = 0;
            if (isUpdatingLineComboBox) return;

            if (TypeOfLine.SelectedItem is ComboBoxItem selectedItem)
            {
                string selectedContent = selectedItem.Content.ToString();

                isUpdatingLineComboBox = true;

                if (selectedContent == "Основная")
                {
                    TypeOfLine.Items.Clear();
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Основная" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Отвлетление" });


                    TypeOfLine.SelectedIndex = 0;
                }

                else if (selectedContent == "Отвлетление")
                {
                    TypeOfLine.Items.Clear();
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Силовая, параллельная" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Силовая, параллельное (упр)" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Питание, сращивание" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Питание, разветление" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Продолжение" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Петля" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Сращивание, концевой сегмент" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Сращивание, средний сегмент" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Разветление, средний сегмент" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Разветление, концевой сегмент" });
                    TypeOfLine.Items.Add(new ComboBoxItem { Content = "Основная" });

                    TypeOfLine.SelectedIndex = 0;
                }

                isUpdatingLineComboBox = false;
                OnDataChanged();
            }
        }
        private void OnDataChanged(object sender, TextChangedEventArgs e)
        {
            if (isProcessingSelectionChange == false)
            {
                Calculate.Background = new SolidColorBrush(Colors.Red);

                var brush = new SolidColorBrush(Colors.Red);
                Calculate.BorderBrush = brush;

                var animation = new ColorAnimation
                {
                    From = Colors.Red,
                    To = Colors.Transparent,
                    Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                    AutoReverse = true,
                    RepeatBehavior = RepeatBehavior.Forever
                };

                brush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
            }

        }
        private void OnDataChanged()
        {
            if (isProcessingSelectionChange == false)
            {
                Calculate.Background = new SolidColorBrush(Colors.Red);

                var brush = new SolidColorBrush(Colors.Red);
                Calculate.BorderBrush = brush;

                var animation = new ColorAnimation
                {
                    From = Colors.Red,
                    To = Colors.Transparent,
                    Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                    AutoReverse = true,
                    RepeatBehavior = RepeatBehavior.Forever
                };

                brush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
            }

        }
        private void Edit_Panels(object sender, RoutedEventArgs e)
        {
            var editPanels = new EditPanels();
            editPanels.PanelsChanged += () =>
            {
                Panels.Items.Clear();
                Panels.ItemsSource = null;
                AddItemsToComboBox(Panels, Config.Config.Instance.Panels.Select(panel => panel.NameOfPanel));
                Panels.Items.Refresh();
            };
            if (editPanels.ShowDialog() == true)
            {

            }
        }
        private void Pipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;
            if (selectedItem == null) return;
            var fileName = currentFilePath;
            var jsonString = File.ReadAllText(fileName);
            var jsonObject = JsonConvert.DeserializeObject<dynamic>(jsonString);
            List<UserPipeLines> userPipeLinesList = new List<UserPipeLines>();
            if (jsonObject != null && jsonObject.UserPipeLines != null)
            {
                userPipeLinesList = JsonConvert.DeserializeObject<List<UserPipeLines>>(jsonObject.UserPipeLines.ToString());
            }
            var pipeLineToEdit = userPipeLinesList.FirstOrDefault(p => p.NameLine == selectedItem.Header.ToString());
            if (pipeLineToEdit == null) return;
            if (pipeLineToEdit.Parameters == null) return;

            if (Pipes.SelectedItem == null) return;
            string selectedContent = Pipes.SelectedItem.ToString();
            if (selectedContent == null) return;
            int spaceIndex = selectedContent.IndexOf('\t');
            string pipeName;
            if (spaceIndex > 0)
            {
                pipeName = selectedContent.Substring(0, spaceIndex);
            }
            else
            {
                pipeName = selectedContent;
            }
            var searchPipe = Config.Config.Instance.Pipes.FirstOrDefault(x => x.Name == pipeName);

            string type = string.Empty;
            if (searchPipe != null)
            {
                type = searchPipe.TypeOfMaterial;
            }
            Diam.Items.Clear();
            Diam.Visibility = Visibility.Visible;
            DiamBox.Visibility = Visibility.Collapsed;
            if (type.Contains("Стальная бесшовная"))
            {
                Diam.Items.Clear();

                AddDiameterOptions(new List<string>
                {
                "6", "7", "8", "9", "10", "11", "12", "13", "14",
                "15", "16", "17", "18", "19", "20", "21", "22",
                "23", "24", "25", "26", "27", "28", "29", "30",
                "32", "34", "35", "36", "38", "40", "42", "45",
                "48", "50", "51", "53", "54", "56", "57", "60",
                "63", "65", "68", "70", "73", "75", "76", "80",
                "83", "85", "89", "90", "95", "100", "102", "108",
                "110", "120", "130", "140", "150", "160", "170",
                "180", "190", "200", "210", "220", "240", "250",
                "273", "299", "325", "351", "377", "402", "406",
                "426", "450", "465", "480", "500", "530", "550"
                });
                Diam.Text = pipeLineToEdit.Parameters.AdditionalParamForPipe.Diam;

            }
            else if (type.Contains("Стальная электросварная"))
            {
                Diam.Items.Clear();

                AddDiameterOptions(new List<string>
                {
                "16", "18", "19", "20", "25", "28", "30", "32",
                "35", "38", "40", "42", "48", "51", "57", "60",
                "76", "89", "102", "108", "114", "127", "133",
                "159", "219", "273", "325", "377", "426", "530",
                "630", "720", "820", "920", "1020", "1220", "1320",
                "1420", "1520", "1620", "1720", "1820", "1920", "2020"
                });
                Diam.Text = pipeLineToEdit.Parameters.AdditionalParamForPipe.Diam;

            }
            else if (type.Contains("Нержавеющая сталь"))
            {
                Diam.Items.Clear();

                AddDiameterOptions(new List<string>
                {
                "8", "9", "10", "11", "12", "14", "15", "16",
                "17 (условный)", "18", "19 (условный)", "20", "22",
                "25", "28", "30", "32", "33", "34", "35", "36",
                "38", "40", "42", "43", "45", "48", "50", "51",
                "53", "55", "56", "57", "60", "63", "65", "70",
                "76", "83", "89", "102", "114", "125", "140",
                "165", "219", "325"
                });
                Diam.Text = pipeLineToEdit.Parameters.AdditionalParamForPipe.Diam;

            }
            else if (type.Contains("Медная труба"))
            {
                Diam.Items.Clear();
                AddDiameterOptions(new List<string>
                {
                "1/4 — 6 мм", "3/8 — 10 мм", "1/2 — 12 мм",
                "5/8 — 16 мм", "3/4 — 18 мм", "7/8 — 22 мм",
                "11/8 — 28 мм", "13/8 — 35 мм", "15/8 — 42 мм",
                "21/8 — 54 мм"
                });
                Diam.Text = pipeLineToEdit.Parameters.AdditionalParamForPipe.Diam;

            }
            else
            {
                DiamBox.Visibility = Visibility.Visible;
                Diam.Visibility = Visibility.Collapsed;
            }
            Diam.Text = pipeLineToEdit.Parameters.AdditionalParamForPipe.Diam;

            OnDataChanged();
        }
        private void AddDiameterOptions(List<string> options)
        {
            foreach (var option in options)
            {
                Diam.Items.Add(new ComboBoxItem { Content = option });
            }
        }
        public class ThermalConductivityCalculator
        {
            private readonly Dictionary<string, Func<int, string>> thermalConductivityFunctions = new Dictionary<string, Func<int, string>>();

            public ThermalConductivityCalculator()
            {
                thermalConductivityFunctions.Add("Цилиндры минераловатные 80", CalculateMineralCylinders80);
                thermalConductivityFunctions.Add("Цилиндры минераловатные 100", CalculateMineralCylinders100);
                thermalConductivityFunctions.Add("Цилиндры минераловатные 150", CalculateMineralCylinders150);
                thermalConductivityFunctions.Add("Маты минераловатные", CalculateMineralMats);
                thermalConductivityFunctions.Add("Плиты минераловатные", CalculateMineralPlates);
                thermalConductivityFunctions.Add("Пеностекло", CalculateFoamGlass);
                thermalConductivityFunctions.Add("Rockwool Цилиндры навивные 100", CalculateRockwoolCylinders);
                thermalConductivityFunctions.Add("Rockwool ТЕХ МАТ", CalculateRockwoolTechMat);
                thermalConductivityFunctions.Add("Rockwool Wired МАТ 80", CalculateRockwoolWiredMat80);
                thermalConductivityFunctions.Add("Аэрогель Pyrogel XT", CalculateAerogelXT);
                thermalConductivityFunctions.Add("Шнур асбестовый пуховой ШАП", CalculateAsbestineCord);
                thermalConductivityFunctions.Add("Шнур энергетический ШТЭ", CalculateEnergeticCord);
                thermalConductivityFunctions.Add("Пенополиуретан", CalculatePolyurethane);
                thermalConductivityFunctions.Add("К-Flex", CalculateKFlex);
            }

            public string CalculateThermalConductivity(string supportedTemp, string layer)
            {
                if (string.IsNullOrEmpty(supportedTemp) || !int.TryParse(supportedTemp, out var temp))
                    return "";

                foreach (var item in thermalConductivityFunctions)
                {
                    if (layer.Contains(item.Key))
                    {
                        return item.Value(temp);
                    }
                }

                return "";
            }

            private string CalculateMineralCylinders80(int temp) => temp < 20 ? "0,0380" : (0.044 + (0.00022 * temp)).ToString();
            private string CalculateMineralCylinders100(int temp) => temp < 20 ? "0,0400" : (0.049 + (0.00021 * temp)).ToString();
            private string CalculateMineralCylinders150(int temp) => temp < 20 ? "0,0420" : (0.05 + (0.0002 * temp)).ToString();
            private string CalculateMineralMats(int temp) => temp < 20 ? "0,0380" : (0.038 + (0.00021 * temp)).ToString();
            private string CalculateMineralPlates(int temp) => temp < 20 ? "0,0390" : (0.039 + (0.00022 * temp)).ToString();
            private string CalculateFoamGlass(int temp) => temp < 20 ? "0,0450" : (0.05 + (0.0002 * temp)).ToString();
            private string CalculateRockwoolCylinders(int temp) => temp < 20 ? "0,0380" : (5e-7 * Math.Pow(temp, 2) + 3e-5 * temp + 0.0374).ToString();
            private string CalculateRockwoolTechMat(int temp) => temp < 20 ? "0,0360" : (4e-7 * Math.Pow(temp, 2) + 0.0001 * temp + 0.0342).ToString();
            private string CalculateRockwoolWiredMat80(int temp) => temp < 20 ? "0,0360" : (4e-7 * Math.Pow(temp, 2) + 0.0001 * temp + 0.0342).ToString();
            private string CalculateAerogelXT(int temp) => temp < 20 ? "0,0210" : (3e-10 * temp * 3 - 3e-8 * Math.Pow(temp, 2) + 3e-5 * temp + 0.0199).ToString();
            private string CalculateAsbestineCord(int temp) => temp < 20 ? "0,0930" : (0.093 + (0.0002 * temp)).ToString();
            private string CalculateEnergeticCord(int temp) => temp < 20 ? "0,0500" : (0.05 + (0.0002 * temp)).ToString();
            private string CalculatePolyurethane(int temp) => temp < 20 ? "0,033" : (0.032 + (0.00015 * temp)).ToString();
            private string CalculateKFlex(int temp) => temp < 20 ? "0,034" : (0.036 + (0.0001 * temp)).ToString();
        }
        private void Diam_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Diam.SelectedItem is ComboBoxItem selectedItem)
            {
                DiamBox.Text = string.Empty;
            }
            OnDataChanged();
        }
        private void Nutrition_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            OnDataChanged();
        }
        private void ThermalIsolation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            OnDataChanged();
        }
        private void PipeLinesTree_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            //var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;

            //if (selectedItem != null && selectedItem.HasItems == false)
            //{
            //    ChangeUserPipeLine(sender, e);
            //}
        }
        private void PipeLinesTree_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedItem = PipeLinesTree.SelectedItem as TreeViewItem;

            if (selectedItem != null && selectedItem.HasItems == false)
            {
                ChangeUserPipeLine(sender, e);
            }
        }
        private void ProductCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedCategory = ProductCategory.SelectedItem.ToString();
            if (selectedCategory == null) return;
            Product.Items.Clear();
            if (selectedCategory.Contains("Механический"))
            {
                Product.Items.Add("ВЗОР ВД-ТП(ц)");
            }
            if (selectedCategory.Contains("Электронный"))
            {
                Product.Items.Add("terneo XD");
                Product.Items.Add("PTDC-*-1");
            }
        }



        private void UpdateAdditionalParam(AdditionalParamForPipe additionalParam)
        {
            additionalParam.Diam = string.IsNullOrEmpty(DiamBox.Text) ? Diam.Text : DiamBox.Text;
            additionalParam.WallThickness = WallThickness.Text;
            additionalParam.Lenght = Lenght.Text;
        }
        private void UpdateTempParam(TempParamForPipe tempParam)
        {
            tempParam.SupportedTemp = SupportedTemp.Text;
            tempParam.MinEnvironment = MinEnvironment.Text;
            tempParam.MaxEnvironment = MaxEnvironment.Text;
            tempParam.MaxImpactOnCable = MaxImpactOnCable.Text;
            tempParam.MaxWorkingPipe = MaxWorkingPipe.Text;
            tempParam.MaxAllowableProduct = MaxAllowableProduct.Text;
        }
        private void UpdateNutrition(NutritionParamForPipe nutrition)
        {
            nutrition.Nutrition = Nutrition.Text;
            nutrition.MaxCurrent = MaxCurrent.Text;
            nutrition.Voltage = Voltage.Text;
            nutrition.WorkingVoltageGrCable = WorkingVoltageGrCable.Text;
        }
        private void UpdateThermalIsolationForPipe(ThermalInsulationForPipe insulationForPipe)
        {
            insulationForPipe.ThicknessIsolation = ThicknessIsolation.Text;
        }
        private void UpdateIsolationParam(ThermalInsulation thermalInsulation)
        {
            string fullNameThermIsol = ThermalIsolationCombobox.Text;
            string[] partsIsol = null;
            ThermalInsulation findIsolation = null;
            if (!string.IsNullOrEmpty(fullNameThermIsol))
            {
                partsIsol = fullNameThermIsol.Split('\t');
                findIsolation = Config.Config.Instance.ThermalInsulations.FirstOrDefault(x => x.Layer == partsIsol[0]);

            }
            if (findIsolation != null)
            {
                var calculator = new ThermalConductivityCalculator();
                thermalInsulation.Layer = findIsolation.Layer;
                thermalInsulation.Thickness = findIsolation.Thickness;
                thermalInsulation.HeatCapacity = findIsolation.HeatCapacity;
                thermalInsulation.Description = findIsolation.Description;
                thermalInsulation.Density = findIsolation.Density;
                thermalInsulation.Diam = findIsolation.Diam;
                thermalInsulation.MinTemp = findIsolation.MinTemp;
                thermalInsulation.MaxTemp = findIsolation.MaxTemp;
                thermalInsulation.ThermalConductivity = calculator.CalculateThermalConductivity(SupportedTemp.Text, thermalInsulation.Layer);
            }
        }
        private void UpdateAreaParam(Areas areaForPipe)
        {
            Areas findArea = null;

            if (!string.IsNullOrEmpty(AreaComboBox.Text))
            {
                findArea = Config.Config.Instance.Areas.FirstOrDefault(x => x.AreaName == AreaComboBox.Text);
            }
            if (findArea != null)
            {
                areaForPipe.AreaName = findArea.AreaName;
            }
        }
        private void UpdateLiquidParam(Liquids liquidForPipe)
        {
            string fullNameLiquid = LiquidComboBox.Text;
            string[] partsLiquid = null;
            Liquids findLiquid = null;
            if (!string.IsNullOrEmpty(fullNameLiquid))
            {
                partsLiquid = fullNameLiquid.Split('\t');
                findLiquid = Config.Config.Instance.Liquids.FirstOrDefault(x => x.NameOfLiquid == partsLiquid[0]);
            }
            if (findLiquid != null)
            {
                liquidForPipe.NameOfLiquid = findLiquid.NameOfLiquid;
                liquidForPipe.LatentHeatOfVaporization = findLiquid.LatentHeatOfVaporization;
                liquidForPipe.LatentHeatOfVaporizationIsFound = findLiquid.LatentHeatOfVaporizationIsFound;
                liquidForPipe.LatentHeatOfFusion = findLiquid.LatentHeatOfFusion;
                liquidForPipe.LatentHeatOfFusionIsFound = findLiquid.LatentHeatOfFusionIsFound;
            }
        }
        private void UpdateLocationParam(Location location)
        {
            location.InDoor = InDoor.IsChecked;
            location.OutDoor = OutDoor.IsChecked;
            location.SchemeForPipe = SchemeForPipe.Text;
            location.HeatLossReserve = HeatLossReserve.Text;
            location.ColdStartTemperature = ColdStartTemperature.Text;
            location.ChimicalExposure = ChimicalExposure.Text;
            location.WindSpeed = WindSpeed.Text;
            location.Comm = Comm.Text;
        }
        private void UpdateClassZoneParam(ClassZone classZone)
        {
            classZone.Normal = toggleZoneCheckBox.IsChecked;
            classZone.Zone1 = Zone1.IsChecked;
            classZone.Zone2 = Zone2.IsChecked;
            classZone.Zone21 = Zone21.IsChecked;
            classZone.Zone22 = Zone22.IsChecked;
            classZone.SetTclassEquipment = SetTclassEquipment.IsChecked;
            classZone.SetAutoignitionTemperature = SetAutoignitionTemperature.IsChecked;
            classZone.Tclass = Tclass.Text;
            classZone.StabilizedСalculation = toggleStab.IsChecked;
            classZone.UseATemperatureLimiter = toggleTemp.IsChecked;
            classZone.SettingTheControlDeviceLimit = SettingTheControlDeviceLimit.Text;
        }
        private void UpdateNutritionComponentParam(NutritioComponentParam nutritionComponent)
        {
            nutritionComponent.ConnectionTypeManualCheck = TypeConnectionManualCheckBox.IsChecked;
            nutritionComponent.ConnectionTypeManual = TypeConnectionManual.Text;
            nutritionComponent.SelectAComponentToConnectCheck = SelectAComponentToConnectCheckBox.IsChecked;
            nutritionComponent.SelectAComponentToConnect = SelectAComponentToConnect.Text;
            nutritionComponent.GroundPlateCheck = GroundPlateCheck.IsChecked;
            nutritionComponent.OutsidePipeCheck = OutsidePipeCheck.IsChecked;
            nutritionComponent.BacklightCheck = BacklightCheck.IsChecked;
            nutritionComponent.UnderInsulationCheck = UnderInsulationCheck.IsChecked;
        }
        private void UpdateEndComponentParam(EndComponentParam endComponent)
        {
            endComponent.EndConnectionTypeManualCheck = EndConnectionTypeManualCheck.IsChecked;
            endComponent.EndConnectionTypeManual = EndConnectionTypeManual.Text;
            endComponent.EndSelectAComponentToConnectCheck = EndSelectAComponentToConnectCheck.IsChecked;
            endComponent.EndSelectAComponentToConnect = EndSelectAComponentToConnect.Text;
            endComponent.EndGroundPlateCheck = EndGroundPlateCheck.IsChecked;
            endComponent.EndBacklightCheck = EndBacklightCheck.IsChecked;
            endComponent.EndUnderInsulationCheck = EndUnderInsulationCheck.IsChecked;
            endComponent.EndOutsidePipeCheck = EndOutsidePipeCheck.IsChecked;
        }
        private void UpdatePanelParam(Panels panel)
        {
            panel.NameOfPanel = Panels.Text;
            panel.RegMethod = RegMethod.Text;
            panel.Sensor = Sensors.Text;
            panel.SecondSensor = Sensors2.Text;
        }
        private void UpdateHeatCableParam(HeatCableParam heatCableParam)
        {
            if (heatCableParam != null)
            {
                heatCableParam.Category = Category.Text;
                heatCableParam.Veins = Veins.Text;
                heatCableParam.Spiral = Spiral.IsChecked;
                heatCableParam.SetKoef = toggleKoef.IsChecked;
                heatCableParam.SetFastener = toggleProj.IsChecked;
                heatCableParam.HeatCablesGroupName = HeatCablesGroupName.Text;
                heatCableParam.HeatCablesName = HeatCablesName.Text;
                heatCableParam.Fastener = SetFastenersComboBox.Text;
            }
        }

    }

}
