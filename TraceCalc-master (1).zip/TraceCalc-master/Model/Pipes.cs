﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class Pipes
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string TypeOfMaterial { get; set; }
        public string HeatCapacity { get; set; }
        public string Density { get; set; }
    }
}
