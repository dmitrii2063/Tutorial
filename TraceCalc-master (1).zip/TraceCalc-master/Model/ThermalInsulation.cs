﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class ThermalInsulation
    {
        public string Layer { get; set; }
        public string Description { get; set; }
        public string Thickness { get; set; }
        public string Diam { get; set; }
        public string MaxTemp { get; set; }
        public string MinTemp { get; set; }
        public string HeatCapacity { get; set; }
        public string Density { get; set; }
        public string ThermalConductivity { get; set; }


        public override string ToString()
        {
            return Layer; 
        }
    }
}
