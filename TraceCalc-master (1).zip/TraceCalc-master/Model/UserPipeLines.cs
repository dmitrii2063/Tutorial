﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class UserPipeLinesData
    {
        public List<UserPipeLines> UserPipeLines { get; set; }
    }
    public class UserPipeLines
    {
        public string NameLine { get; set; }
        public string Section { get; set; }
        public string LineType { get; set; }
        public string Main { get; set; }
        public Param Parameters { get; set; }


        public class Param
        {
            public Pipes Pipe { get; set; }
            public ThermalInsulation Insulation { get; set; }
            public Areas Area { get; set; }
            public Liquids Liquid { get; set; }
            public AdditionalParamForPipe AdditionalParamForPipe { get; set; }
            public TempParamForPipe TempParamForPipe { get; set; }
            public NutritionParamForPipe NutritionParamForPipe { get; set; }
            public ThermalInsulationForPipe ThermalInsulationForPipe { get; set; }
            public Location Location { get; set; }
            public ClassZone ClassZone { get; set; }
            public NutritioComponentParam NutritioComponentParam { get; set; }
            public EndComponentParam EndComponentParam { get; set; }
            public Panels Panels { get; set; }
            public HeatCableParam HeatCableParam { get; set; }
        }



        public class AdditionalParamForPipe
        {
            public string Lenght { get; set; }
            public string WallThickness { get; set; }
            public string Diam { get; set; }
        }
        public class TempParamForPipe
        {
            public string SupportedTemp { get; set; }
            public string MinEnvironment { get; set; }
            public string MaxEnvironment { get; set; }
            public string MaxImpactOnCable { get; set; }
            public string MaxWorkingPipe { get; set; }
            public string MaxAllowableProduct { get; set; }
        }
        public class NutritionParamForPipe
        {
            public string Nutrition { get; set; }
            public string Voltage { get; set; }
            public string WorkingVoltageGrCable { get; set; }
            public string MaxCurrent { get; set; }
        }
        public class ThermalInsulationForPipe
        {
            public string ThicknessIsolation { get; set; }
        }
        public class Location
        {
            public bool? InDoor {  get; set; }
            public bool? OutDoor {  get; set; }
            public string SchemeForPipe { get; set; }
            public string WindSpeed { get; set; }
            public string ChimicalExposure { get; set; }
            public string ColdStartTemperature { get; set; }
            public string HeatLossReserve { get; set; }
            public string Comm {  get; set; }
        }
        public class ClassZone
        {
            public string Standart { get; set; }
            public bool? Normal { get; set; }
            public bool? Zone1 { get; set; }
            public bool? Zone2 { get; set; }
            public bool? Zone21 { get; set; }
            public bool? Zone22 { get; set; }
            public bool? SetTclassEquipment { get; set; }
            public string Tclass {  get; set; }
            public bool? SetAutoignitionTemperature { get; set; }
            public bool? StabilizedСalculation { get; set; }
            public bool? UseATemperatureLimiter { get; set; }
            public string SettingTheControlDeviceLimit { get; set; }
        }

        public class NutritioComponentParam
        {
            public bool? ConnectionTypeManualCheck { get; set; }
            public string ConnectionTypeManual { get; set; }
            public bool? SelectAComponentToConnectCheck { get; set; }
            public string SelectAComponentToConnect { get; set; }
            public bool? GroundPlateCheck { get; set; }
            public bool? OutsidePipeCheck { get; set; }
            public bool? BacklightCheck { get; set; }
            public bool? UnderInsulationCheck { get; set; }
        }
        public class EndComponentParam
        {
            public bool? EndConnectionTypeManualCheck { get; set; }
            public string EndConnectionTypeManual { get; set; }
            public bool? EndSelectAComponentToConnectCheck { get; set; }
            public string EndSelectAComponentToConnect { get; set; }
            public bool? EndGroundPlateCheck { get; set; }
            public bool? EndOutsidePipeCheck { get; set; }
            public bool? EndBacklightCheck { get; set; }
            public bool? EndUnderInsulationCheck { get; set; }
        }

        public class HeatCableParam
        {
            public string Category { get; set; }
            public string Veins { get; set; }
            public bool? Spiral { get; set; }
            public bool? SetFastener { get; set; }
            public string Fastener { get; set; }
            public bool? SetKoef { get; set; }
            public string HeatCablesGroupName { get; set; }
            public string HeatCablesName { get; set; }
        }

    }
}
