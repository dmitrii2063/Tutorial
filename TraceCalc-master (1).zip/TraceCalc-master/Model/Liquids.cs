﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class Liquids
    {
        public string NameOfLiquid { get; set; }
        public string Description { get; set; }
        public string LatentHeatOfFusion { get; set; }
        public string LatentHeatOfFusionIsFound { get; set; }
        public string LatentHeatOfVaporization { get; set; }
        public string LatentHeatOfVaporizationIsFound { get; set; }
        public bool? CanFreeze { get; set; }
        public bool? CanBoil { get; set; }
        public string HeatCapacity{ get; set; }
        public string Density{ get; set; }
        public string ThermalConductivity { get; set; }

    }
}
