﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class HeatCables
    {
        public string HeatCablesGroupName { get; set; }
        public List<NameOfHeatCables> HeatCablesName { get; set; }
        public List<Seal> Seals { get; set; }
        
        
        public class NameOfHeatCables
        {
            public string Name { get; set; }
        }
        public class Seal
        {
            public string NameOfSeal { get; set; }
        }
    }
}
