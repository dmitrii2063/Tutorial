﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class Panels
    {
        public string NameOfPanel { get; set; }
        public string RegMethod { get; set; }
        public string Product { get; set; }
        public string Sensor { get; set; }
        public string SecondSensor { get; set; }
    }
}
