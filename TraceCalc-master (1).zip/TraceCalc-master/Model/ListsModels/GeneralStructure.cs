﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model.ListsModels
{
    public class GeneralStructure
    {
        public List<Pipes> Pipes { get; set; }
        public ValvesAndSupportsAndFlangs ValvesAndSupportsAndFlangs { get; set; }
        public List<ThermalInsulation> ThermalInsulations { get; set; }
        public List<Liquids> Liquids { get; set; }
        public List<Areas> Areas { get; set; }
        public List<Fasteners> Fasteners { get; set; }
        public List<HeatCables> HeatCables { get; set; }
        public List<Panels> Panels { get; set; }
        public List<Sensor> Sensors { get; set; }
        public List<LocalControl> LocalControls { get; set; }

    }
}
