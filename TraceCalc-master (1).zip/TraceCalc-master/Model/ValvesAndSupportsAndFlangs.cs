﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TraceCalc.Model
{
    public class ValvesAndSupportsAndFlangs
    {
        public List<Valves> Valves;
        public List<Supports> Supports;
        public List<Flangs> Flangs;
    }
    public class Valves
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public string Mode { get; set; }
        public string Interval { get; set; }
        public string Quantity { get; set; }
        public string Max { get; set; }
        public string ImagePath { get; set; }

    }
    public class Supports
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public string Mode { get; set; }
        public string Interval { get; set; }
        public string Quantity { get; set; }
        public string Max { get; set; }
        public string ImagePath { get; set; }

    }
    public class Flangs
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public string Mode { get; set; }
        public string Interval { get; set; }
        public string Quantity { get; set; }
        public string Max { get; set; }
        public string ImagePath { get; set; }

    }
}
